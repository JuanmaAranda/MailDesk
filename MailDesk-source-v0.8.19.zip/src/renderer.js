const state = {
  accounts: [],
  messages: [],
  selectedAccountId: '',
  selectedFolder: 'inbox',
  selectedMessage: null,
  selectedDetail: null,
  composeContext: null,
  editingAccountId: '',
  settings: {}
};

const elements = {
  accountNav: document.querySelector('#accountNav'),
  accountDialog: document.querySelector('#accountDialog'),
  accountForm: document.querySelector('#accountForm'),
  accountError: document.querySelector('#accountError'),
  composeDialog: document.querySelector('#composeDialog'),
  composeForm: document.querySelector('#composeForm'),
  composeError: document.querySelector('#composeError'),
  translationNotice: document.querySelector('#translationNotice'),
  settingsDialog: document.querySelector('#settingsDialog'),
  settingsForm: document.querySelector('#settingsForm'),
  settingsError: document.querySelector('#settingsError'),
  settingsStatus: document.querySelector('#settingsStatus'),
  openRouterStatusDot: document.querySelector('#openRouterStatusDot'),
  openRouterStatusTitle: document.querySelector('#openRouterStatusTitle'),
  openRouterStatusText: document.querySelector('#openRouterStatusText'),
  openRouterTopStatus: document.querySelector('#openRouterTopStatus'),
  updateStatus: document.querySelector('#updateStatus'),
  installUpdateButton: document.querySelector('#installUpdateButton'),
  messageList: document.querySelector('#messageList'),
  reader: document.querySelector('#reader'),
  viewTitle: document.querySelector('#viewTitle'),
  statusText: document.querySelector('#statusText'),
  searchInput: document.querySelector('#searchInput'),
  toast: document.querySelector('#toast')
};

const savedTheme = localStorage.getItem('maildesk-theme') || 'light';
applyTheme(savedTheme);

document.querySelector('#addAccountButton').addEventListener('click', openAccountDialog);
document.querySelector('#settingsButton').addEventListener('click', openSettingsDialog);
document.querySelector('#settingsTopButton').addEventListener('click', openSettingsDialog);
document.querySelector('#composeButton').addEventListener('click', () => openComposeDialog());
document.querySelector('#refreshButton').addEventListener('click', loadMessages);
document.querySelector('#themeToggle').addEventListener('click', toggleTheme);
document.querySelector('#sidebarToggle').addEventListener('click', toggleSidebar);
document.querySelector('#testAccountButton').addEventListener('click', testAccount);
document.querySelector('#removeAccountButton').addEventListener('click', removeAccount);
document.querySelector('#testOpenRouterButton').addEventListener('click', testOpenRouter);
document.querySelector('#generateDraftButton').addEventListener('click', generateDraft);
elements.accountForm.addEventListener('submit', saveAccount);
elements.composeForm.addEventListener('submit', sendMessage);
elements.settingsForm.addEventListener('submit', saveSettings);
elements.searchInput.addEventListener('input', renderMessages);
elements.accountForm.elements.signatureHtml.addEventListener('input', updateSignaturePreview);
elements.accountForm.elements.providerPreset.addEventListener('change', applyProviderPreset);
elements.accountForm.elements.email.addEventListener('input', syncProviderUsers);
elements.composeForm.elements.accountId.addEventListener('change', () => replaceComposeSignature(elements.composeForm.elements.accountId.value));
document.querySelectorAll('[data-editor-command]').forEach((button) => button.addEventListener('click', () => runEditorCommand(button.dataset.editorCommand)));
document.querySelector('#insertLinkButton').addEventListener('click', insertEditorLink);
document.querySelector('#removeFormatButton').addEventListener('click', () => runEditorCommand('removeFormat'));
document.querySelector('#checkUpdatesButton').addEventListener('click', checkForUpdates);
elements.installUpdateButton.addEventListener('click', () => window.maildesk.updater.install());
document.querySelectorAll('.close-dialog').forEach((button) => button.addEventListener('click', () => button.closest('dialog').close()));
document.querySelectorAll('[data-folder]').forEach((button) => button.addEventListener('click', () => selectFolder(button.dataset.folder)));
window.maildesk.updater.onStatus(handleUpdaterStatus);
applySidebar(localStorage.getItem('maildesk-sidebar-collapsed') === 'true');

async function init() {
  [state.accounts, state.settings] = await Promise.all([
    window.maildesk.accounts.list(),
    window.maildesk.settings.get()
  ]);
  renderAccounts();
  updateOpenRouterStatus(state.settings.hasOpenRouterKey ? 'unknown' : 'offline', state.settings.hasOpenRouterKey ? 'Pendiente de comprobación' : 'No hay ninguna clave configurada');
  if (state.settings.hasOpenRouterKey) testOpenRouter({ silent: true });
  if (state.accounts.length) await loadMessages();
  setInterval(() => { if (state.accounts.length && !document.hidden) loadMessages({ silent: true }); }, 5 * 60 * 1000);
}

function renderAccounts() {
  elements.accountNav.replaceChildren();
  const select = elements.composeForm.elements.accountId;
  select.replaceChildren();

  state.accounts.forEach((account) => {
    const row = document.createElement('div');
    row.className = 'account-row';
    const button = document.createElement('button');
    button.className = `nav-item${state.selectedAccountId === account.id ? ' active' : ''}`;
    button.dataset.account = account.id;
    const dot = document.createElement('span');
    dot.className = 'account-dot';
    dot.style.background = account.color;
    const identity = document.createElement('span');
    identity.className = 'account-identity sidebar-label';
    const name = document.createElement('span');
    name.className = 'account-name';
    name.textContent = account.sidebarName || account.name || account.email;
    const email = document.createElement('span');
    email.className = 'account-email';
    email.textContent = account.email;
    identity.append(name, email);
    button.append(dot, identity);
    button.addEventListener('click', () => selectAccount(account.id));
    button.addEventListener('contextmenu', (event) => editAccount(event, account));
    const editButton = document.createElement('button');
    editButton.className = 'account-edit-button';
    editButton.type = 'button';
    editButton.title = `Configurar ${account.email} y su firma`;
    editButton.textContent = '⚙';
    editButton.addEventListener('click', (event) => editAccount(event, account));
    row.append(button, editButton);
    elements.accountNav.append(row);

    const option = document.createElement('option');
    option.value = account.id;
    option.textContent = `${account.name} <${account.email}>`;
    select.append(option);
  });
}

async function selectAccount(id) {
  state.selectedAccountId = id;
  updateNavigation();
  const account = state.accounts.find((item) => item.id === id);
  elements.viewTitle.textContent = account ? `${account.name} · ${folderTitle(state.selectedFolder)}` : folderTitle(state.selectedFolder);
  clearReader();
  await loadMessages();
}

async function selectFolder(folder) {
  state.selectedFolder = folder;
  state.selectedAccountId = '';
  updateNavigation();
  elements.viewTitle.textContent = folderTitle(folder);
  clearReader();
  await loadMessages();
}

function updateNavigation() {
  document.querySelectorAll('[data-folder]').forEach((item) => item.classList.toggle('active', item.dataset.folder === state.selectedFolder));
  document.querySelectorAll('[data-account]').forEach((item) => item.classList.toggle('active', Boolean(item.dataset.account) && item.dataset.account === state.selectedAccountId));
}

async function loadMessages(options = {}) {
  if (!state.accounts.length) return;
  if (!options.silent) elements.messageList.innerHTML = '<div class="loading">Conectando con tus buzones…</div>';
  elements.statusText.textContent = 'Actualizando…';
  try {
    const result = await window.maildesk.messages.list({ limit: 50, accountId: state.selectedAccountId || undefined, folder: state.selectedFolder });
    state.messages = result.messages;
    renderMessages();
    elements.statusText.textContent = `${state.messages.length} mensajes en ${folderTitle(state.selectedFolder).toLowerCase()}${result.errors.length ? ` · ${result.errors.length} cuenta(s) con error` : ''}`;
    const notices = [...result.errors.map((item) => item.message), result.aiError].filter(Boolean);
    if (notices.length) showToast(notices.join(' · '));
  } catch (error) {
    elements.messageList.innerHTML = `<div class="loading">${escapeHtml(error.message)}</div>`;
    elements.statusText.textContent = 'No se ha podido actualizar';
  }
}

function renderMessages() {
  const query = elements.searchInput.value.trim().toLowerCase();
  const messages = state.messages.filter((message) => `${message.from} ${message.fromEmail} ${message.subject} ${message.accountEmail}`.toLowerCase().includes(query));
  elements.messageList.replaceChildren();
  if (!messages.length) {
    elements.messageList.innerHTML = '<div class="empty-state"><div class="empty-icon">✉</div><h2>No hay mensajes</h2><p>Prueba a actualizar o cambia la búsqueda.</p></div>';
    return;
  }

  messages.forEach((message) => {
    const card = document.createElement('article');
    card.className = `message-card${message.unread ? ' unread' : ''}`;
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    const top = document.createElement('div');
    top.className = 'message-top';
    const sender = document.createElement('span');
    sender.className = 'sender';
    sender.textContent = message.from || message.fromEmail || 'Remitente desconocido';
    const date = document.createElement('span');
    date.className = 'date';
    date.textContent = formatDate(message.date);
    top.append(sender, date);
    const subject = document.createElement('div');
    subject.className = 'subject';
    subject.textContent = message.subject;
    const chip = document.createElement('div');
    chip.className = 'account-chip';
    const dot = document.createElement('span');
    dot.className = 'account-dot';
    dot.style.background = message.accountColor;
    chip.append(dot, document.createTextNode(message.accountEmail));
    const quickActions = document.createElement('div');
    quickActions.className = 'message-quick-actions';
    quickActions.append(
      createQuickAction('↩', 'Responder', () => quickCompose(message, 'reply')),
      createQuickAction('→', 'Reenviar', () => quickCompose(message, 'forward')),
      createQuickAction('🗑', message.folder === 'trash' ? 'Eliminar definitivamente' : 'Mover a la papelera', () => executeMessageAction(message.folder === 'trash' ? 'delete' : 'trash', message))
    );
    card.append(top, subject, chip, quickActions);
    card.addEventListener('click', () => openMessage(message, card));
    card.addEventListener('dblclick', () => openMessageWindow(message));
    card.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openMessage(message, card); }
    });
    elements.messageList.append(card);
  });
}

function createQuickAction(icon, title, handler) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'message-quick-action';
  button.title = title;
  button.setAttribute('aria-label', title);
  button.textContent = icon;
  button.addEventListener('click', (event) => { event.stopPropagation(); handler(); });
  button.addEventListener('dblclick', (event) => event.stopPropagation());
  return button;
}

async function quickCompose(message, mode) {
  try {
    showToast(mode === 'reply' ? 'Abriendo respuesta…' : 'Abriendo reenvío…');
    const detail = await window.maildesk.messages.read({ accountId: message.accountId, uid: message.uid, mailbox: message.mailbox });
    openComposeDialog({ mode, message, detail });
  } catch (error) {
    showToast(error.message);
  }
}

async function openMessageWindow(message) {
  try {
    await window.maildesk.messages.openWindow({
      accountId: message.accountId,
      uid: message.uid,
      mailbox: message.mailbox,
      theme: document.documentElement.dataset.theme,
      loadRemoteImages: state.settings.loadRemoteImages
    });
  } catch (error) {
    showToast(`No se ha podido abrir la ventana: ${error.message}`);
  }
}

async function openMessage(message, card) {
  document.querySelectorAll('.message-card').forEach((item) => item.classList.remove('active'));
  card.classList.add('active');
  card.classList.remove('unread');
  elements.reader.innerHTML = '<div class="loading">Abriendo mensaje…</div>';
  state.selectedMessage = message;
  try {
    const detail = await window.maildesk.messages.read({ accountId: message.accountId, uid: message.uid, mailbox: message.mailbox });
    state.selectedDetail = detail;
    renderReader(message, detail);
  } catch (error) {
    elements.reader.innerHTML = `<div class="loading">${escapeHtml(error.message)}</div>`;
  }
}

function renderReader(message, detail) {
  const wrapper = document.createElement('article');
  wrapper.className = 'reader-content';

  const title = document.createElement('h2');
  title.textContent = detail.subject;
  wrapper.append(title);

  if (detail.translated) {
    const badge = document.createElement('div');
    badge.className = 'translation-badge';
    badge.textContent = `✦ Traducido del ${languageName(detail.originalLanguage)}`;
    wrapper.append(badge);
  }
  if (detail.translationError) {
    const warning = document.createElement('div');
    warning.className = 'translation-warning';
    warning.textContent = `No se ha podido traducir: ${detail.translationError}`;
    wrapper.append(warning);
  }

  const meta = document.createElement('div');
  meta.className = 'message-meta';
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = (message.from || '?').slice(0, 1).toUpperCase();
  const lines = document.createElement('div');
  lines.className = 'meta-line';
  lines.innerHTML = `<strong>${escapeHtml(detail.from)}</strong><br>Para: ${escapeHtml(detail.to)}${detail.cc ? `<br>CC: ${escapeHtml(detail.cc)}` : ''}<br>${escapeHtml(formatFullDate(detail.date))}`;
  meta.append(avatar, lines);

  const body = createEmailViewer(detail.html);

  wrapper.append(meta, createToolbar(message, detail), body);
  if (detail.attachments.length) {
    const attachments = document.createElement('div');
    attachments.className = 'attachment-list';
    const heading = document.createElement('strong');
    heading.textContent = `📎 ${detail.attachments.length} archivo${detail.attachments.length === 1 ? '' : 's'} adjunto${detail.attachments.length === 1 ? '' : 's'}`;
    const grid = document.createElement('div');
    grid.className = 'attachment-grid';
    detail.attachments.forEach((item) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'attachment-card';
      button.innerHTML = `<span class="attachment-icon">${attachmentIcon(item.contentType)}</span><span><strong>${escapeHtml(item.filename)}</strong><small>${escapeHtml(formatBytes(item.size))}</small></span><span class="attachment-download">↓</span>`;
      button.addEventListener('click', () => saveAttachment(message, item, button));
      grid.append(button);
    });
    attachments.append(heading, grid);
    wrapper.append(attachments);
  }
  elements.reader.replaceChildren(wrapper);
}

function createToolbar(message, detail) {
  const toolbar = document.createElement('div');
  toolbar.className = 'reader-toolbar';
  const primaryActions = [
    ['↩', 'Responder', () => openComposeDialog({ mode: 'reply', message, detail })],
    ['↩↩', 'Responder a todos', () => openComposeDialog({ mode: 'replyAll', message, detail })],
    ['→', 'Reenviar', () => openComposeDialog({ mode: 'forward', message, detail })],
    ['✦', detail.translationChecked ? (detail.translated ? 'Traducido' : 'Ya está en español') : 'Traducir', detail.translationChecked ? () => {} : (_event, button) => translateMessage(message, detail, button), detail.translationChecked ? 'translated' : 'translate'],
    ['│', '', null]
  ];
  const folderActions = message.folder === 'trash'
    ? [['↶', 'Recuperar en la bandeja de entrada', () => executeMessageAction('restore', message)], ['🗑', 'Eliminar definitivamente', () => executeMessageAction('delete', message), 'danger']]
    : message.folder === 'spam'
      ? [['↶', 'Recuperar en la bandeja de entrada', () => executeMessageAction('restore', message)], ['🗑', 'Papelera', () => executeMessageAction('trash', message), 'danger']]
      : [['▣', 'Archivar', () => executeMessageAction('archive', message)], ['✉', 'No leído', () => executeMessageAction('unread', message)], ['★', 'Destacar', () => executeMessageAction('star', message)], ['🛑', 'Spam', () => executeMessageAction('spam', message)], ['🗑', 'Papelera', () => executeMessageAction('trash', message), 'danger']];
  const actions = [...primaryActions, ...folderActions];
  actions.forEach(([icon, label, handler, extraClass]) => {
    if (!handler) {
      const separator = document.createElement('span');
      separator.className = 'toolbar-separator';
      toolbar.append(separator);
      return;
    }
    const button = document.createElement('button');
    button.className = `reader-action ${extraClass || ''}`;
    button.type = 'button';
    button.innerHTML = `<span>${icon}</span><span>${label}</span>`;
    if (extraClass === 'translated') button.disabled = true;
    button.addEventListener('click', (event) => handler(event, button));
    toolbar.append(button);
  });
  return toolbar;
}

async function translateMessage(message, detail, button) {
  if (!state.settings.hasOpenRouterKey) {
    showToast('Configura primero tu clave de OpenRouter en Ajustes.');
    return;
  }
  const selectedKey = `${message.accountId}:${message.mailbox}:${message.uid}`;
  button.disabled = true;
  button.innerHTML = '<span>✦</span><span>Traduciendo…</span>';
  try {
    const translated = await window.maildesk.messages.translate({ accountId: message.accountId, uid: message.uid, mailbox: message.mailbox });
    if (`${state.selectedMessage?.accountId}:${state.selectedMessage?.mailbox}:${state.selectedMessage?.uid}` !== selectedKey) return;
    state.selectedDetail = translated;
    renderReader(message, translated);
    showToast(translated.translated ? 'Mensaje traducido al español' : 'El mensaje ya está en español');
  } catch (error) {
    button.disabled = false;
    button.innerHTML = '<span>✦</span><span>Traducir</span>';
    showToast(error.message);
  }
}

async function saveAttachment(message, attachment, button) {
  const previous = button.innerHTML;
  button.disabled = true;
  button.querySelector('.attachment-download').textContent = '…';
  try {
    const result = await window.maildesk.messages.saveAttachment({
      accountId: message.accountId,
      uid: message.uid,
      mailbox: message.mailbox,
      attachmentId: attachment.id
    });
    if (result.ok) showToast('Archivo adjunto guardado');
  } catch (error) {
    showToast(error.message);
  } finally {
    button.innerHTML = previous;
    button.disabled = false;
  }
}

function createEmailViewer(html) {
  const iframe = document.createElement('iframe');
  iframe.className = 'email-frame';
  iframe.title = 'Contenido del mensaje';
  iframe.setAttribute('sandbox', 'allow-same-origin allow-popups allow-popups-to-escape-sandbox');
  iframe.setAttribute('referrerpolicy', 'no-referrer');
  iframe.srcdoc = prepareEmailDocument(html);
  iframe.addEventListener('load', () => {
    const documentHeight = iframe.contentDocument?.documentElement?.scrollHeight || iframe.contentDocument?.body?.scrollHeight || 500;
    iframe.style.height = `${Math.min(Math.max(documentHeight + 8, 320), 2400)}px`;
  });
  return iframe;
}

function prepareEmailDocument(html) {
  const parser = new DOMParser();
  const documentValue = parser.parseFromString(String(html || ''), 'text/html');
  documentValue.querySelectorAll('script, iframe, object, embed, form, base, meta[http-equiv="refresh"]').forEach((element) => element.remove());
  documentValue.querySelectorAll('*').forEach((element) => {
    [...element.attributes].forEach((attribute) => {
      if (/^on/i.test(attribute.name) || /javascript:/i.test(attribute.value)) element.removeAttribute(attribute.name);
    });
  });
  documentValue.querySelectorAll('a[href]').forEach((link) => {
    if (!/^https?:/i.test(link.href)) link.removeAttribute('href');
    else {
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
  });
  if (!state.settings.loadRemoteImages) {
    documentValue.querySelectorAll('img').forEach((image) => {
      if (/^https?:/i.test(image.src)) {
        image.removeAttribute('src');
        image.alt = image.alt || '[Imagen externa bloqueada]';
      }
    });
  }
  const security = documentValue.createElement('meta');
  security.httpEquiv = 'Content-Security-Policy';
  security.content = "default-src 'none'; img-src data: https:; style-src 'unsafe-inline' https:; font-src data: https:; frame-src 'none'; object-src 'none'; form-action 'none'";
  const baseStyle = documentValue.createElement('style');
  baseStyle.textContent = 'html,body{margin:0;padding:0;background:#fff;color:#222;max-width:100%;overflow-x:auto} body{padding:2px;font-family:Arial,sans-serif} img{max-width:100%;height:auto} table{max-width:100%} pre{white-space:pre-wrap}';
  documentValue.head.prepend(security, baseStyle);
  return `<!doctype html>${documentValue.documentElement.outerHTML}`;
}

async function executeMessageAction(action, message = state.selectedMessage) {
  if (!message) return;
  const labels = { archive: 'Archivando…', unread: 'Marcando como no leído…', star: 'Destacando…', spam: 'Moviendo a spam…', trash: 'Moviendo a la papelera…', restore: 'Recuperando…', delete: 'Eliminando definitivamente…' };
  showToast(labels[action] || 'Procesando…');
  try {
    await window.maildesk.messages.action({
      accountId: message.accountId,
      uid: message.uid,
      mailbox: message.mailbox,
      action
    });
    if (state.selectedMessage?.accountId === message.accountId && state.selectedMessage?.uid === message.uid) clearReader();
    await loadMessages();
    showToast('Acción completada');
  } catch (error) {
    showToast(error.message);
  }
}

function clearReader() {
  state.selectedMessage = null;
  state.selectedDetail = null;
  elements.reader.innerHTML = '<div class="reader-placeholder"><div>✉</div><h2>Selecciona un mensaje</h2><p>Aquí aparecerá el contenido del correo.</p></div>';
}

function openAccountDialog() {
  state.editingAccountId = '';
  elements.accountForm.reset();
  elements.accountForm.elements.imapPort.value = '993';
  elements.accountForm.elements.smtpPort.value = '465';
  elements.accountForm.elements.imapSecure.checked = true;
  elements.accountForm.elements.smtpSecure.checked = true;
  elements.accountForm.elements.color.value = '#2f648f';
  elements.accountForm.elements.providerPreset.value = 'custom';
  updateProviderHelp('custom');
  elements.accountError.textContent = '';
  document.querySelector('#removeAccountButton').hidden = true;
  updateSignaturePreview();
  elements.accountDialog.showModal();
}

function editAccount(event, account) {
  event.preventDefault();
  openAccountDialog();
  state.editingAccountId = account.id;
  const removeButton = document.querySelector('#removeAccountButton');
  removeButton.hidden = false;
  removeButton.textContent = 'Eliminar cuenta';
  const form = elements.accountForm.elements;
  form.id.value = account.id;
  form.name.value = account.name;
  form.sidebarName.value = account.sidebarName || account.name || account.email;
  form.email.value = account.email;
  form.color.value = account.color;
  form.imapHost.value = account.imap.host;
  form.imapPort.value = account.imap.port;
  form.imapSecure.checked = account.imap.secure;
  form.imapUser.value = account.imap.user;
  form.smtpHost.value = account.smtp.host;
  form.smtpPort.value = account.smtp.port;
  form.smtpSecure.checked = account.smtp.secure;
  form.smtpUser.value = account.smtp.user;
  form.signatureHtml.value = account.signatureHtml || '';
  form.providerPreset.value = detectProviderPreset(account);
  updateProviderHelp(form.providerPreset.value);
  updateSignaturePreview();
}

async function removeAccount() {
  const account = state.accounts.find((item) => item.id === state.editingAccountId);
  if (!account || !confirm(`¿Eliminar «${account.sidebarName || account.email}» de MailDesk?`)) return;
  await window.maildesk.accounts.remove(account.id);
  state.accounts = state.accounts.filter((item) => item.id !== account.id);
  state.selectedAccountId = '';
  elements.accountDialog.close();
  renderAccounts();
  clearReader();
  await loadMessages();
}

const PROVIDER_PRESETS = {
  hostinger: {
    imapHost: 'imap.hostinger.com', imapPort: '993', imapSecure: true,
    smtpHost: 'smtp.hostinger.com', smtpPort: '465', smtpSecure: true,
    help: 'Hostinger · IMAP 993 con SSL/TLS y SMTP 465 con SSL/TLS.'
  },
  gmail: {
    imapHost: 'imap.gmail.com', imapPort: '993', imapSecure: true,
    smtpHost: 'smtp.gmail.com', smtpPort: '465', smtpSecure: true,
    help: 'Gmail · Usa tu dirección completa como usuario y una contraseña de aplicación de Google de 16 caracteres; no uses tu contraseña habitual.'
  },
  outlook: {
    imapHost: 'outlook.office365.com', imapPort: '993', imapSecure: true,
    smtpHost: 'smtp-mail.outlook.com', smtpPort: '587', smtpSecure: false,
    help: 'Outlook.com · IMAP debe estar habilitado. Microsoft puede requerir autenticación moderna u contraseña de aplicación.'
  }
};

function applyProviderPreset() {
  const form = elements.accountForm.elements;
  const preset = PROVIDER_PRESETS[form.providerPreset.value];
  updateProviderHelp(form.providerPreset.value);
  if (!preset) return;
  form.imapHost.value = preset.imapHost;
  form.imapPort.value = preset.imapPort;
  form.imapSecure.checked = preset.imapSecure;
  form.smtpHost.value = preset.smtpHost;
  form.smtpPort.value = preset.smtpPort;
  form.smtpSecure.checked = preset.smtpSecure;
  syncProviderUsers();
}

function syncProviderUsers() {
  const form = elements.accountForm.elements;
  if (!PROVIDER_PRESETS[form.providerPreset.value] || !form.email.value.trim()) return;
  form.imapUser.value = form.email.value.trim();
  form.smtpUser.value = form.email.value.trim();
}

function updateProviderHelp(provider) {
  document.querySelector('#providerHelp').textContent = PROVIDER_PRESETS[provider]?.help || 'Puedes seleccionar un proveedor para rellenar los servidores automáticamente o introducirlos a mano.';
}

function detectProviderPreset(account) {
  return Object.entries(PROVIDER_PRESETS).find(([, preset]) => account.imap.host === preset.imapHost && account.smtp.host === preset.smtpHost)?.[0] || 'custom';
}

function accountFromForm() {
  const form = elements.accountForm.elements;
  return {
    id: form.id.value || undefined,
    name: form.name.value,
    sidebarName: form.sidebarName.value,
    email: form.email.value,
    password: form.password.value,
    color: form.color.value,
    imap: { host: form.imapHost.value, port: form.imapPort.value, secure: form.imapSecure.checked, user: form.imapUser.value },
    smtp: { host: form.smtpHost.value, port: form.smtpPort.value, secure: form.smtpSecure.checked, user: form.smtpUser.value },
    signatureHtml: form.signatureHtml.value
  };
}

function updateSignaturePreview() {
  const preview = document.querySelector('#signaturePreview');
  const html = elements.accountForm.elements.signatureHtml.value.trim();
  preview.innerHTML = html || '<span>Vista previa de la firma</span>';
  preview.querySelectorAll('script, iframe, object, embed, form').forEach((element) => element.remove());
  preview.querySelectorAll('*').forEach((element) => {
    [...element.attributes].forEach((attribute) => {
      if (/^on/i.test(attribute.name) || /javascript:/i.test(attribute.value)) element.removeAttribute(attribute.name);
    });
  });
}

async function testAccount() {
  elements.accountError.textContent = 'Probando conexión segura…';
  try {
    await window.maildesk.accounts.test(accountFromForm());
    elements.accountError.textContent = '';
    showToast('Conexión IMAP y SMTP correcta');
  } catch (error) {
    elements.accountError.textContent = error.message;
  }
}

async function saveAccount(event) {
  event.preventDefault();
  elements.accountError.textContent = '';
  try {
    await window.maildesk.accounts.save(accountFromForm());
    elements.accountDialog.close();
    state.accounts = await window.maildesk.accounts.list();
    renderAccounts();
    showToast('Cuenta guardada');
    await loadMessages();
  } catch (error) {
    elements.accountError.textContent = error.message;
  }
}

function openComposeDialog(context = null) {
  if (!state.accounts.length) return showToast('Primero debes añadir una cuenta');
  elements.composeForm.reset();
  document.querySelector('#messageEditor').innerHTML = '';
  elements.composeError.textContent = '';
  elements.translationNotice.textContent = '';
  state.composeContext = context;
  const form = elements.composeForm.elements;
  const editor = document.querySelector('#messageEditor');

  if (context) {
    const { mode, message, detail } = context;
    form.accountId.value = message.accountId;
    form.targetLanguage.value = detail.originalLanguage || 'und';
    form.inReplyTo.value = detail.messageId || '';
    form.references.value = [...(detail.references || []), detail.messageId].filter(Boolean).join('\n');

    if (mode === 'reply' || mode === 'replyAll') {
      form.to.value = detail.fromAddress;
      form.subject.value = replySubject(detail.subject);
      if (mode === 'replyAll') {
        const ownAddress = message.accountEmail.toLowerCase();
        const recipients = new Set([detail.fromAddress, ...detail.toAddresses, ...detail.ccAddresses].filter(Boolean));
        const filtered = [...recipients].filter((address) => address.toLowerCase() !== ownAddress);
        form.to.value = filtered.shift() || detail.fromAddress;
        form.cc.value = filtered.join(', ');
      }
      if (detail.originalLanguage && detail.originalLanguage !== 'es' && detail.originalLanguage !== 'und') {
        elements.translationNotice.textContent = `Escribe en español. Antes de enviar se traducirá automáticamente al ${languageName(detail.originalLanguage)}.`;
      }
    } else if (mode === 'forward') {
      form.subject.value = forwardSubject(detail.subject);
      editor.innerHTML = `<p><br></p><hr><p><strong>Mensaje reenviado</strong><br>De: ${escapeHtml(detail.from)}<br>Fecha: ${escapeHtml(formatFullDate(detail.date))}<br>Asunto: ${escapeHtml(detail.subject)}<br>Para: ${escapeHtml(detail.to)}</p><blockquote>${detail.html}</blockquote>`;
      form.targetLanguage.value = '';
      form.inReplyTo.value = '';
      form.references.value = '';
    }
  }
  appendComposeSignature(form.accountId.value);
  elements.composeDialog.showModal();
}

async function generateDraft() {
  const form = elements.composeForm.elements;
  const instruction = form.aiInstruction.value.trim();
  elements.composeError.textContent = 'La IA está preparando el borrador…';
  try {
    const draft = await window.maildesk.ai.draft({
      instruction,
      message: state.composeContext?.detail || null
    });
    if (draft.subject && !form.subject.value) form.subject.value = draft.subject;
    const editor = document.querySelector('#messageEditor');
    const signature = editor.querySelector('[data-maildesk-signature]')?.outerHTML || '';
    editor.innerHTML = `${textToEditorHtml(draft.body)}${signature}`;
    elements.composeError.textContent = '';
    showToast('Borrador generado en español');
  } catch (error) {
    elements.composeError.textContent = error.message;
  }
}

async function sendMessage(event) {
  event.preventDefault();
  const form = elements.composeForm.elements;
  const editor = document.querySelector('#messageEditor');
  const plainBody = editor.innerText.trim();
  if (!plainBody) {
    elements.composeError.textContent = 'Escribe el contenido del mensaje.';
    return;
  }
  const targetLanguage = form.targetLanguage.value;
  elements.composeError.textContent = targetLanguage && !['es', 'und'].includes(targetLanguage)
    ? 'Traduciendo al idioma original y enviando…'
    : 'Enviando…';
  try {
    await window.maildesk.messages.send({
      accountId: form.accountId.value,
      to: form.to.value,
      cc: form.cc.value,
      bcc: form.bcc.value,
      subject: form.subject.value,
      body: plainBody,
      html: editor.innerHTML,
      targetLanguage,
      inReplyTo: form.inReplyTo.value,
      references: form.references.value.split('\n').filter(Boolean)
    });
    elements.composeDialog.close();
    showToast('Mensaje enviado correctamente');
  } catch (error) {
    elements.composeError.textContent = error.message;
  }
}

async function openSettingsDialog() {
  state.settings = await window.maildesk.settings.get();
  const form = elements.settingsForm.elements;
  form.openRouterKey.value = '';
  form.openRouterModel.value = state.settings.openRouterModel;
  form.translateReplies.checked = state.settings.translateReplies;
  form.loadRemoteImages.checked = state.settings.loadRemoteImages;
  elements.settingsStatus.textContent = state.settings.hasOpenRouterKey ? 'Hay una clave de OpenRouter configurada.' : 'Todavía no hay una clave de OpenRouter configurada.';
  elements.settingsError.textContent = '';
  elements.settingsDialog.showModal();
}

async function saveSettings(event) {
  event.preventDefault();
  const form = elements.settingsForm.elements;
  elements.settingsError.textContent = '';
  try {
    if (form.openRouterKey.value.trim()) {
      elements.settingsError.textContent = 'Validando la clave con OpenRouter…';
      await testOpenRouter({ key: form.openRouterKey.value, throwOnError: true });
      elements.settingsError.textContent = '';
    }
    state.settings = await window.maildesk.settings.save({
      openRouterKey: form.openRouterKey.value,
      openRouterModel: form.openRouterModel.value,
      translateReplies: form.translateReplies.checked,
      loadRemoteImages: form.loadRemoteImages.checked
    });
    elements.settingsDialog.close();
    showToast('Ajustes guardados');
    if (state.accounts.length) await loadMessages();
  } catch (error) {
    elements.settingsError.textContent = error.message;
  }
}

async function testOpenRouter(options = {}) {
  const isEvent = options instanceof Event;
  const settingsForm = elements.settingsForm.elements;
  const key = isEvent ? settingsForm.openRouterKey.value : options.key;
  const button = document.querySelector('#testOpenRouterButton');
  if (button) button.disabled = true;
  updateOpenRouterStatus('checking', 'Comprobando la conexión con OpenRouter…');
  try {
    const result = await window.maildesk.ai.validate({ openRouterKey: key || '' });
    updateOpenRouterStatus('online', result.limitRemaining == null
      ? 'Clave válida y conexión activa.'
      : `Clave válida · saldo disponible: ${Number(result.limitRemaining).toFixed(2)} créditos.`);
    if (!options.silent && !isEvent) showToast('Conexión con OpenRouter correcta');
    return result;
  } catch (error) {
    updateOpenRouterStatus('offline', error.message);
    if (options.throwOnError) throw error;
    if (!options.silent) showToast(error.message);
    return null;
  } finally {
    if (button) button.disabled = false;
  }
}

function updateOpenRouterStatus(status, message) {
  const labels = { online: 'OpenRouter conectado', offline: 'OpenRouter desconectado', checking: 'Comprobando OpenRouter…', unknown: 'OpenRouter sin comprobar' };
  [elements.openRouterStatusDot, elements.openRouterTopStatus].filter(Boolean).forEach((dot) => {
    dot.className = `connection-dot ${status}`;
    dot.title = labels[status];
  });
  if (elements.openRouterStatusTitle) elements.openRouterStatusTitle.textContent = labels[status];
  if (elements.openRouterStatusText) elements.openRouterStatusText.textContent = message;
}

async function checkForUpdates() {
  elements.updateStatus.textContent = 'Buscando actualizaciones…';
  try {
    const result = await window.maildesk.updater.check();
    if (!result.ok) elements.updateStatus.textContent = result.message;
  } catch (error) {
    elements.updateStatus.textContent = error.message;
  }
}

function handleUpdaterStatus({ status, message }) {
  elements.updateStatus.textContent = message;
  elements.installUpdateButton.hidden = status !== 'ready';
  if (status === 'ready') showToast(message);
}

function runEditorCommand(command, value = null) {
  const editor = document.querySelector('#messageEditor');
  editor.focus();
  document.execCommand(command, false, value);
}

function insertEditorLink() {
  const url = window.prompt('Dirección del enlace (https://…)');
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) return showToast('El enlace debe comenzar por http:// o https://');
  runEditorCommand('createLink', url);
}

function appendComposeSignature(accountId) {
  const editor = document.querySelector('#messageEditor');
  if (editor.querySelector('[data-maildesk-signature]')) return;
  const account = state.accounts.find((item) => item.id === accountId);
  if (!account?.signatureHtml) return;
  editor.insertAdjacentHTML('beforeend', `<div data-maildesk-signature="true"><br>${account.signatureHtml}</div>`);
}

function replaceComposeSignature(accountId) {
  const editor = document.querySelector('#messageEditor');
  editor.querySelectorAll('[data-maildesk-signature]').forEach((signature) => signature.remove());
  appendComposeSignature(accountId);
}

function textToEditorHtml(text) {
  return String(text || '')
    .split(/\n{2,}/)
    .map((paragraph) => `<p>${escapeHtml(paragraph).replaceAll('\n', '<br>')}</p>`)
    .join('');
}

function replySubject(subject) {
  return /^re:/i.test(subject) ? subject : `Re: ${subject}`;
}

function forwardSubject(subject) {
  return /^(fw|fwd):/i.test(subject) ? subject : `Fwd: ${subject}`;
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add('visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => elements.toast.classList.remove('visible'), 4200);
}

function toggleTheme() {
  applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}

function toggleSidebar() {
  applySidebar(!document.querySelector('.app-shell').classList.contains('sidebar-collapsed'));
}

function applySidebar(collapsed) {
  document.querySelector('.app-shell').classList.toggle('sidebar-collapsed', collapsed);
  localStorage.setItem('maildesk-sidebar-collapsed', String(collapsed));
  const button = document.querySelector('#sidebarToggle');
  button.textContent = collapsed ? '›' : '‹';
  button.title = collapsed ? 'Desplegar barra lateral' : 'Contraer barra lateral';
  button.setAttribute('aria-label', button.title);
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem('maildesk-theme', theme);
  const button = document.querySelector('#themeToggle');
  if (!button) return;
  const dark = theme === 'dark';
  button.textContent = dark ? '☀' : '☾';
  button.title = dark ? 'Desactivar modo oscuro' : 'Activar modo oscuro';
  button.setAttribute('aria-label', button.title);
}

function attachmentIcon(contentType) {
  if (/^image\//i.test(contentType || '')) return '🖼';
  if (/pdf/i.test(contentType || '')) return 'PDF';
  if (/zip|compressed|archive/i.test(contentType || '')) return 'ZIP';
  return '📄';
}

function languageName(code) {
  const names = { en: 'inglés', fr: 'francés', de: 'alemán', it: 'italiano', pt: 'portugués', ca: 'catalán', nl: 'neerlandés', es: 'español', und: 'idioma original' };
  return names[String(code || '').toLowerCase()] || String(code || 'original').toUpperCase();
}

function folderTitle(folder) {
  return ({ inbox: 'Bandeja unificada', trash: 'Papelera unificada', spam: 'Spam unificado' })[folder] || 'Bandeja unificada';
}

function formatDate(date) {
  const value = new Date(date);
  const today = new Date();
  return value.toDateString() === today.toDateString()
    ? value.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
    : value.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
}

function formatFullDate(date) {
  return date ? new Date(date).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' }) : '';
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`;
}

function stripHtml(html) {
  const container = document.createElement('div');
  container.innerHTML = html;
  return container.textContent || '';
}

function escapeHtml(value) {
  return String(value || '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

init();
