const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { safeStorage } = require('electron');

class AccountStore {
  constructor(userDataPath) {
    this.filePath = path.join(userDataPath, 'accounts.json');
  }

  readAll() {
    if (!fs.existsSync(this.filePath)) return [];
    try {
      const data = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  }

  writeAll(accounts) {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const temporaryPath = `${this.filePath}.tmp`;
    fs.writeFileSync(temporaryPath, JSON.stringify(accounts, null, 2), { mode: 0o600 });
    fs.renameSync(temporaryPath, this.filePath);
  }

  encrypt(value) {
    if (!safeStorage.isEncryptionAvailable()) {
      throw new Error('Windows no permite cifrar las credenciales en este momento.');
    }
    return safeStorage.encryptString(value).toString('base64');
  }

  decrypt(value) {
    return safeStorage.decryptString(Buffer.from(value, 'base64'));
  }

  listPublic() {
    return this.readAll().map(({ encryptedPassword, ...account }) => ({
      ...account,
      hasPassword: Boolean(encryptedPassword)
    }));
  }

  getWithPassword(id) {
    const account = this.readAll().find((item) => item.id === id);
    if (!account) throw new Error('La cuenta seleccionada ya no existe.');
    return {
      ...account,
      password: this.decrypt(account.encryptedPassword)
    };
  }

  save(input) {
    const accounts = this.readAll();
    const index = accounts.findIndex((item) => item.id === input.id);
    const previous = index >= 0 ? accounts[index] : null;
    const id = input.id || crypto.randomUUID();
    const password = input.password?.trim();

    if (!password && !previous?.encryptedPassword) {
      throw new Error('Introduce la contraseña de la cuenta.');
    }

    const account = {
      id,
      name: input.name.trim(),
      sidebarName: input.sidebarName?.trim() || input.name.trim(),
      email: input.email.trim(),
      color: input.color || '#6750a4',
      imap: normalizeServer(input.imap),
      smtp: normalizeServer(input.smtp),
      signatureHtml: sanitizeSignatureHtml(input.signatureHtml),
      encryptedPassword: password ? this.encrypt(password) : previous.encryptedPassword,
      updatedAt: new Date().toISOString()
    };

    if (index >= 0) accounts[index] = account;
    else accounts.push(account);
    this.writeAll(accounts);
    return { id };
  }

  remove(id) {
    this.writeAll(this.readAll().filter((item) => item.id !== id));
    return { ok: true };
  }
}

function normalizeServer(server) {
  return {
    host: server.host.trim(),
    port: Number(server.port),
    secure: Boolean(server.secure),
    user: server.user.trim()
  };
}

function sanitizeSignatureHtml(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
    .replace(/<(iframe|object|embed|form|base|meta)[^>]*\/?>/gi, '')
    .replace(/\son\w+\s*=\s*(["']).*?\1/gi, '')
    .replace(/javascript:/gi, '');
}

module.exports = { AccountStore };
