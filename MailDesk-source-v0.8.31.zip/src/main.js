const path = require('node:path');
const fs = require('node:fs/promises');
const { app, BrowserWindow, clipboard, dialog, Menu, ipcMain, nativeImage, shell } = require('electron');
const { autoUpdater } = require('electron-updater');
const { AccountStore } = require('./services/account-store');
const { SettingsStore } = require('./services/settings-store');
const { AiService } = require('./services/ai-service');
const { MailService } = require('./services/mail-service');

let accountStore;
let settingsStore;
let aiService;
let mailService;
let mainWindow;
const messageWindows = new Set();
const unreadBadge = nativeImage.createFromPath(path.join(__dirname, 'assets', 'maildesk-badge.png'));

// Las conexiones TLS de IMAP/SMTP y del actualizador pueden cerrarse
// abruptamente (ECONNRESET). No deben derribar el proceso principal de Electron.
function isTransientNetworkError(error) {
  return ['ECONNRESET', 'ECONNABORTED', 'ETIMEDOUT', 'EPIPE', 'ENETUNREACH'].includes(error?.code);
}
process.on('uncaughtException', (error) => {
  if (isTransientNetworkError(error)) {
    sendUpdaterStatus('network-warning', 'Se ha interrumpido una conexión de red. MailDesk lo reintentará automáticamente.');
    return;
  }
  dialog.showErrorBox('Error de MailDesk', error?.message || 'Se ha producido un error inesperado.');
});
process.on('unhandledRejection', (reason) => {
  if (isTransientNetworkError(reason)) {
    sendUpdaterStatus('network-warning', 'Se ha interrumpido una conexión de red. MailDesk lo reintentará automáticamente.');
  }
});

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#f6f7f9',
    title: 'MailDesk',
    icon: path.join(__dirname, 'assets', 'maildesk-icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      // El refresco automático de IMAP debe seguir funcionando con la app
      // minimizada o sin foco.
      backgroundThrottling: false
    }
  });

  window.setMenuBarVisibility(false);
  installContextMenu(window);
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  window.loadFile(path.join(__dirname, 'index.html'));
  mainWindow = window;
}

function installContextMenu(window) {
  window.webContents.on('context-menu', (_event, params) => {
    const template = [];
    if (params.selectionText) template.push({ label: 'Copiar', role: 'copy' });
    if (params.isEditable) template.push({ label: 'Cortar', role: 'cut' }, { label: 'Copiar', role: 'copy' }, { label: 'Pegar', role: 'paste' });
    if (params.mediaType === 'image') {
      template.push({ label: 'Copiar imagen', click: () => window.webContents.copyImageAt(params.x, params.y) });
      if (params.srcURL) template.push({ label: 'Copiar dirección de imagen', click: () => clipboard.writeText(params.srcURL) });
    }
    if (params.linkURL) template.push({ type: 'separator' }, { label: 'Copiar enlace', click: () => clipboard.writeText(params.linkURL) }, { label: 'Abrir enlace', click: () => shell.openExternal(params.linkURL) });
    template.push({ type: 'separator' }, { label: 'Seleccionar todo', role: 'selectAll' });
    Menu.buildFromTemplate(template).popup({ window });
  });
}

async function createMessageWindow(request) {
  const detail = await mailService.read(request);
  const account = accountStore.listPublic().find((item) => item.id === request.accountId);
  const popup = new BrowserWindow({
    width: 1040,
    height: 820,
    minWidth: 680,
    minHeight: 520,
    backgroundColor: '#ffffff',
    title: `${detail.subject || 'Mensaje'} · MailDesk`,
    icon: path.join(__dirname, 'assets', 'maildesk-icon.png'),
    parent: mainWindow,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });
  popup.setMenuBarVisibility(false);
  installContextMenu(popup);
  popup.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  messageWindows.add(popup);
  popup.on('closed', () => messageWindows.delete(popup));
  popup.webContents.once('did-finish-load', () => popup.webContents.send('messages:window-data', {
    message: {
      accountId: request.accountId,
      accountEmail: account?.email || '',
      uid: request.uid,
      mailbox: request.mailbox || 'INBOX',
      from: detail.from
    },
    detail,
    theme: request.theme === 'dark' ? 'dark' : 'light',
    loadRemoteImages: request.loadRemoteImages !== false
  }));
  await popup.loadFile(path.join(__dirname, 'message-window.html'));
  return { ok: true };
}

function sendUpdaterStatus(status, message = '') {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('updater:status', { status, message });
}

function setupAutoUpdater() {
  if (!app.isPackaged) return;
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => sendUpdaterStatus('checking', 'Buscando actualizaciones…'));
  autoUpdater.on('update-available', (info) => sendUpdaterStatus('downloading', `Descargando MailDesk ${info.version}…`));
  autoUpdater.on('update-not-available', () => sendUpdaterStatus('current', 'MailDesk está actualizado.'));
  autoUpdater.on('download-progress', (progress) => sendUpdaterStatus('downloading', `Descargando actualización: ${Math.round(progress.percent)} %`));
  autoUpdater.on('update-downloaded', (info) => sendUpdaterStatus('ready', `MailDesk ${info.version} está listo para instalar.`));
  autoUpdater.on('error', (error) => sendUpdaterStatus('error', `No se ha podido actualizar: ${error.message}`));
  setTimeout(() => autoUpdater.checkForUpdates().catch(() => {}), 8000);
}

function registerHandlers() {
  ipcMain.handle('accounts:list', () => accountStore.listPublic());
  ipcMain.handle('accounts:save', (_event, account) => accountStore.save(account));
  ipcMain.handle('accounts:remove', (_event, id) => accountStore.remove(id));
  ipcMain.handle('accounts:test', (_event, account) => mailService.test(account));
  ipcMain.handle('settings:get', () => settingsStore.getPublic());
  ipcMain.handle('settings:save', (_event, settings) => settingsStore.save(settings));
  ipcMain.handle('ai:validate', (_event, request) => aiService.validateConnection(request));
  ipcMain.handle('messages:list', (_event, options) => mailService.listUnified(options));
  ipcMain.handle('messages:read', (_event, request) => mailService.read(request));
  ipcMain.handle('messages:translate', (_event, request) => mailService.translate(request));
  ipcMain.handle('messages:action', (_event, request) => mailService.action(request));
  ipcMain.handle('messages:send', (_event, message) => mailService.send(message));
  ipcMain.handle('messages:save-attachment', async (_event, request) => {
    const attachment = await mailService.attachment(request);
    const safeName = path.basename(attachment.filename).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(mainWindow, { defaultPath: safeName });
    if (result.canceled || !result.filePath) return { ok: false, canceled: true };
    await fs.writeFile(result.filePath, attachment.content);
    return { ok: true, filePath: result.filePath };
  });
  ipcMain.handle('messages:open-window', (_event, request) => createMessageWindow(request));
  ipcMain.handle('ai:draft', (_event, request) => aiService.draftReply(request));
  ipcMain.handle('updater:check', async () => {
    if (!app.isPackaged) return { ok: false, message: 'Las actualizaciones solo funcionan en la versión instalada.' };
    await autoUpdater.checkForUpdates();
    return { ok: true };
  });
  ipcMain.handle('updater:install', () => {
    autoUpdater.quitAndInstall(false, true);
    return { ok: true };
  });
  ipcMain.handle('notifications:badge', (_event, hasUnread) => {
    if (mainWindow && !mainWindow.isDestroyed() && process.platform === 'win32') {
      mainWindow.setOverlayIcon(hasUnread ? unreadBadge : null, hasUnread ? 'Hay correos nuevos sin abrir' : 'No hay correos nuevos');
    }
    return { ok: true };
  });
}

app.whenReady().then(() => {
  accountStore = new AccountStore(app.getPath('userData'));
  settingsStore = new SettingsStore(app.getPath('userData'));
  aiService = new AiService(settingsStore);
  mailService = new MailService(accountStore, aiService, settingsStore);
  registerHandlers();
  createWindow();
  setupAutoUpdater();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
