# MailDesk

Cliente de correo de escritorio para Windows con varias cuentas IMAP/SMTP y bandeja unificada. No utiliza servidores intermedios: la aplicación se conecta directamente desde el ordenador a los proveedores de correo configurados.

## Estado de la versión 0.8.4

- Añadir y editar cuentas IMAP/SMTP.
- Probar ambas conexiones antes de guardar.
- Cifrar las contraseñas usando el almacén seguro del sistema operativo.
- Ver los mensajes recientes de todas las cuentas en una bandeja unificada.
- Filtrar por una cuenta concreta.
- Abrir mensajes HTML o texto en un visor aislado que conserva tablas, botones y estilos.
- Enviar correos seleccionando la cuenta remitente.
- Campos Para, CC y CCO.
- Búsqueda local entre los mensajes cargados.
- Mostrar imágenes remotas e imágenes incrustadas mediante CID.
- Responder, responder a todos y reenviar.
- Archivar, mover a spam o papelera, marcar como no leído y destacar.
- Traducir manualmente el mensaje abierto al español mediante OpenRouter.
- Redactar borradores con instrucciones en lenguaje natural.
- Escribir respuestas en español y traducirlas al idioma original antes de enviarlas.
- Editor visual WYSIWYG con negrita, cursiva, subrayado, listas, alineación y enlaces.
- Firma HTML independiente para cada buzón, con vista previa.
- Acceso visible a Ajustes desde la cabecera y configuración de cada cuenta mediante su engranaje.
- Instalador de Windows generado automáticamente con GitHub Actions.
- Comprobación y descarga automática de nuevas versiones desde GitHub Releases.
- Botón manual para buscar actualizaciones y reiniciar cuando estén listas.
- Mostrar y guardar archivos adjuntos.
- Modo oscuro y nueva identidad visual en azul `#002448`.
- Scroll estable en el panel de lectura, incluso con mensajes largos.
- Apertura del mensaje en una ventana independiente mediante doble clic.
- Validación de la clave de OpenRouter e indicador de conexión tipo semáforo.
- Traducción más rápida al enviar a la IA solamente el texto visible, conservando el HTML.
- Barra lateral izquierda retráctil.
- Fondo diferenciado para los mensajes nuevos que aún no se han abierto.
- Colores y contrastes revisados en modo oscuro.
- Iconos de responder, reenviar y eliminar directamente en cada mensaje del listado.
- Papelera y Spam unificados para todos los buzones, con recuperación a la bandeja de entrada.
- Botones de responder, reenviar y eliminar en cada mensaje, sin cubrir el asunto.
- Cuentas identificadas por su nombre visible y con el correo como referencia secundaria.
- Diagnóstico claro para Gmail cuando falta la contraseña de aplicación.
- Prueba de cuentas por IMAP y SMTP por separado, sin abrir carpetas durante la validación.
- Nombre independiente para cada buzón en la barra lateral, separado del nombre del remitente.
- Las carpetas unificadas eliminan el filtro de cuenta y muestran todos los buzones.
- Perfiles de servidor para Hostinger, Gmail y Outlook.com, con configuración manual disponible.

## Configurar OpenRouter

Abre `Ajustes e IA`, pega una clave de OpenRouter y elige el modelo. MailDesk valida la clave antes de guardarla y muestra un indicador verde cuando la conexión está activa. El modelo predeterminado es `openai/gpt-4.1-mini`. La clave se cifra mediante el almacén seguro de Windows.

La traducción solo se ejecuta al pulsar `Traducir` en la barra del mensaje. La traducción y la redacción con IA envían a OpenRouter el asunto y el contenido del mensaje que se está procesando. El coste depende del modelo, del tamaño de los correos y del número de traducciones. La aplicación guarda una caché temporal en memoria para evitar repetir traducciones durante la misma sesión.

## Ejecutar durante el desarrollo

Requiere Node.js 22 o superior.

```bash
npm install
npm start
```

## Crear el instalador de Windows

En un ordenador Windows:

```bash
npm install
npm run dist:win
```

El instalador se genera en la carpeta `release`.

## Publicar una versión

El repositorio incluye un flujo de GitHub Actions. Al publicar una versión como `v0.8.4`, GitHub compila la aplicación en Windows y publica el instalador, su fichero de bloques y `latest.yml` en GitHub Releases.

Las versiones instaladas comprueban GitHub automáticamente al iniciarse. La versión portátil anterior no puede actualizarse sola: es necesario instalar una vez el instalador NSIS publicado en Releases.

## Seguridad

Las contraseñas no se guardan en texto legible. Electron `safeStorage` utiliza la protección criptográfica del sistema operativo; en Windows se apoya en DPAPI y queda ligada al usuario que inició sesión. El archivo de configuración permanece exclusivamente en el ordenador.

Los mensajes se descargan bajo demanda y no se guardan todavía en una base de datos local. Los adjuntos se muestran como tarjetas y se guardan únicamente cuando el usuario los pulsa y elige una ubicación. Las imágenes incrustadas en el propio correo se representan. Las imágenes externas pueden desactivarse porque algunos remitentes las utilizan para confirmar la apertura del mensaje.

## Próximas mejoras previstas

- Guardar borradores.
- Carpetas Enviados, Spam, Papelera y carpetas personalizadas.
- Sincronización local y funcionamiento sin conexión.
- Notificaciones de Windows y actualización periódica.
- Reglas, etiquetas y firmas por cuenta.
- Instalador firmado.
