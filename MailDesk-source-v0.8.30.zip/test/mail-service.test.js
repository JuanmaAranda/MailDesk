const assert = require('node:assert/strict');
const test = require('node:test');
const { MailService, findDestination, resolveMailbox, friendlyError } = require('../src/services/mail-service');
const { extractVisibleText, restoreTranslatedText } = require('../src/services/ai-service');

const source = Buffer.from([
  'From: Example <sender@example.com>',
  'To: user@example.com',
  'Subject: Styled message',
  'Content-Language: en',
  'MIME-Version: 1.0',
  'Content-Type: multipart/mixed; boundary="maildesk-boundary"',
  '',
  '--maildesk-boundary',
  'Content-Type: text/html; charset=utf-8',
  '',
  '<html lang="en"><head><style>.button{background:#002448;color:white}</style></head><body><table><tr><td><a class="button" href="https://example.com">Open</a></td></tr></table></body></html>',
  '--maildesk-boundary',
  'Content-Type: text/plain; name="notes.txt"',
  'Content-Disposition: attachment; filename="notes.txt"',
  'Content-Transfer-Encoding: base64',
  '',
  'SG9sYSBhZGp1bnRv',
  '--maildesk-boundary--',
  ''
].join('\r\n'));

function createService() {
  const accountStore = { getWithPassword: () => ({ id: 'account-1', password: 'secret', imap: {} }) };
  const aiService = {
    translateInbound: async (_key, message) => ({
      ...message,
      subject: 'Mensaje con estilo',
      originalSubject: message.subject,
      originalHtml: message.html,
      originalLanguage: 'en',
      translated: true,
      translationChecked: true
    })
  };
  const service = new MailService(accountStore, aiService, {});
  service.imapClient = () => ({
    usable: true,
    connect: async () => {},
    mailboxOpen: async () => {},
    fetchOne: async () => ({ source }),
    messageFlagsAdd: async () => {},
    logout: async () => {}
  });
  return service;
}

test('opens styled HTML and attachments without invoking AI', async () => {
  const service = createService();
  const message = await service.read({ accountId: 'account-1', uid: 7 });
  assert.equal(message.translated, false);
  assert.equal(message.originalLanguage, 'en');
  assert.match(message.html, /<style>/i);
  assert.match(message.html, /<table>/i);
  assert.equal(message.attachments.length, 1);
  assert.equal(message.attachments[0].filename, 'notes.txt');
});

test('translates only when explicitly requested and retains downloadable data', async () => {
  const service = createService();
  const translated = await service.translate({ accountId: 'account-1', uid: 7 });
  assert.equal(translated.subject, 'Mensaje con estilo');
  assert.equal(translated.translated, true);
  const attachment = await service.attachment({ accountId: 'account-1', uid: 7, attachmentId: '0' });
  assert.equal(attachment.filename, 'notes.txt');
  assert.equal(attachment.content.toString(), 'Hola adjunto');
});

test('translates visible text without sending or changing email styles and links', () => {
  const html = '<style>.button{color:white}</style><table><tr><td>Hello &amp; welcome</td><td><a href="https://example.com">Open account</a></td></tr></table>';
  const prepared = extractVisibleText(html, 30000);
  assert.deepEqual(prepared.texts, [
    { id: 0, text: 'Hello & welcome' },
    { id: 1, text: 'Open account' }
  ]);
  const translated = restoreTranslatedText(prepared.tokens, new Map([[0, 'Hola y bienvenido'], [1, 'Abrir cuenta']]));
  assert.match(translated, /<style>\.button\{color:white\}<\/style>/);
  assert.match(translated, /href="https:\/\/example\.com"/);
  assert.match(translated, />Hola y bienvenido</);
  assert.match(translated, />Abrir cuenta</);
});

test('finds unified spam and trash folders using IMAP special-use flags', async () => {
  const folders = [
    { path: 'INBOX' },
    { path: '[Gmail]/Spam', specialUse: '\\Junk' },
    { path: '[Gmail]/Trash', specialUse: '\\Trash' }
  ];
  assert.equal(findDestination(folders, 'spam'), '[Gmail]/Spam');
  assert.equal(findDestination(folders, 'trash'), '[Gmail]/Trash');
  assert.equal(await resolveMailbox({ list: async () => folders }, 'spam'), '[Gmail]/Spam');
  assert.equal(await resolveMailbox({ list: async () => folders }, 'trash'), '[Gmail]/Trash');
});

test('finds Sent folders from IMAP attributes and common non-Gmail names', async () => {
  const folders = [
    { path: 'INBOX.Sent Items', attributes: new Set(['\\\\Sent']) },
    { path: 'INBOX.Elementos enviados' }
  ];
  assert.equal(findDestination(folders, 'sent'), 'INBOX.Sent Items');
  assert.equal(await resolveMailbox({ list: async () => [{ path: 'INBOX.Mensajes enviados' }] }, 'sent'), 'INBOX.Mensajes enviados');
});

test('lists every account in the unified Sent view and removes duplicate mailbox UIDs', async () => {
  const accounts = [
    { id: 'gmail', name: 'Gmail', email: 'gmail@example.com' },
    { id: 'hostinger', name: 'Hostinger', email: 'hostinger@example.com' }
  ];
  const service = new MailService({
    listPublic: () => accounts,
    getWithPassword: (id) => ({ ...accounts.find((account) => account.id === id), password: 'secret', imap: {} })
  }, {}, {});
  service.imapClient = (account) => ({
    usable: true,
    connect: async () => {},
    list: async () => account.id === 'gmail'
      ? [{ path: '[Gmail]/Sent Mail', specialUse: '\\Sent' }]
      : [{ path: 'INBOX.Elementos enviados', attributes: ['\\\\Sent'] }],
    mailboxOpen: async () => ({ exists: 2 }),
    fetch: async function* () {
      yield { uid: 9, envelope: { subject: account.name, date: new Date('2026-01-01'), from: [], to: [] }, flags: new Set() };
      yield { uid: 9, envelope: { subject: `${account.name} duplicate`, date: new Date('2026-01-01'), from: [], to: [] }, flags: new Set() };
    },
    logout: async () => {}
  });

  const result = await service.listUnified({ folder: 'sent', limit: 30 });
  assert.equal(result.errors.length, 0);
  assert.equal(result.messages.length, 2);
  assert.deepEqual(new Set(result.messages.map((message) => message.accountId)), new Set(['gmail', 'hostinger']));
});

test('explains Gmail authentication failures without exposing the technical command error', () => {
  const message = friendlyError(new Error('Command failed'), {
    imap: { host: 'imap.gmail.com' },
    smtp: { host: 'smtp.gmail.com' }
  });
  assert.match(message, /contraseña de aplicación/i);
  assert.doesNotMatch(message, /Command failed/i);
});
