const state = {
  accounts: [],
  messages: [],
  selectedAccountId: '',
  selectedMessage: null,
  selectedDetail: null,
  composeContext: null,
  settings: {}
};

const elements = {
  accountNav: document.querySelector('#accountNav'),
  accountDialog: document.querySelector('#accountDialog'),
  accountForm: document.querySelector('#accountForm'),
  accountError: document.querySelector('#accountError'),
  composeDialog: document.querySelector('#composeDialog'),
  composeForm: document.querySelector('#composeForm'),
  composeError: document.querySelector('#composeError'),
  translationNotice: document.querySelector('#translationNotice'),
  settingsDialog: document.querySelector('#settingsDialog'),
  settingsForm: document.querySelector('#settingsForm'),
  settingsError: document.querySelector('#settingsError'),
  settingsStatus: document.querySelector('#settingsStatus'),
  updateStatus: document.querySelector('#updateStatus'),
  installUpdateButton: document.querySelector('#installUpdateButton'),
  messageList: document.querySelector('#messageList'),
  reader: document.querySelector('#reader'),
  viewTitle: document.querySelector('#viewTitle'),
  statusText: document.querySelector('#statusText'),
  searchInput: document.querySelector('#searchInput'),
  toast: document.querySelector('#toast')
};

document.querySelector('#addAccountButton').addEventListener('click', openAccountDialog);
document.querySelector('#settingsButton').addEventListener('click', openSettingsDialog);
document.querySelector('#settingsTopButton').addEventListener('click', openSettingsDialog);
document.querySelector('#composeButton').addEventListener('click', () => openComposeDialog());
document.querySelector('#refreshButton').addEventListener('click', loadMessages);
document.querySelector('#testAccountButton').addEventListener('click', testAccount);
document.querySelector('#generateDraftButton').addEventListener('click', generateDraft);
elements.accountForm.addEventListener('submit', saveAccount);
elements.composeForm.addEventListener('submit', sendMessage);
elements.settingsForm.addEventListener('submit', saveSettings);
elements.searchInput.addEventListener('input', renderMessages);
elements.accountForm.elements.signatureHtml.addEventListener('input', updateSignaturePreview);
elements.composeForm.elements.accountId.addEventListener('change', () => replaceComposeSignature(elements.composeForm.elements.accountId.value));
document.querySelectorAll('[data-editor-command]').forEach((button) => button.addEventListener('click', () => runEditorCommand(button.dataset.editorCommand)));
document.querySelector('#insertLinkButton').addEventListener('click', insertEditorLink);
document.querySelector('#removeFormatButton').addEventListener('click', () => runEditorCommand('removeFormat'));
document.querySelector('#checkUpdatesButton').addEventListener('click', checkForUpdates);
elements.installUpdateButton.addEventListener('click', () => window.maildesk.updater.install());
document.querySelectorAll('.close-dialog').forEach((button) => button.addEventListener('click', () => button.closest('dialog').close()));
document.querySelector('[data-account=""]').addEventListener('click', () => selectAccount(''));
window.maildesk.updater.onStatus(handleUpdaterStatus);

async function init() {
  [state.accounts, state.settings] = await Promise.all([
    window.maildesk.accounts.list(),
    window.maildesk.settings.get()
  ]);
  renderAccounts();
  if (state.accounts.length) await loadMessages();
}

function renderAccounts() {
  elements.accountNav.replaceChildren();
  const select = elements.composeForm.elements.accountId;
  select.replaceChildren();

  state.accounts.forEach((account) => {
    const row = document.createElement('div');
    row.className = 'account-row';
    const button = document.createElement('button');
    button.className = `nav-item${state.selectedAccountId === account.id ? ' active' : ''}`;
    button.dataset.account = account.id;
    const dot = document.createElement('span');
    dot.className = 'account-dot';
    dot.style.background = account.color;
    const label = document.createElement('span');
    label.className = 'nav-email';
    label.textContent = account.email;
    button.append(dot, label);
    button.addEventListener('click', () => selectAccount(account.id));
    button.addEventListener('contextmenu', (event) => editAccount(event, account));
    const editButton = document.createElement('button');
    editButton.className = 'account-edit-button';
    editButton.type = 'button';
    editButton.title = `Configurar ${account.email} y su firma`;
    editButton.textContent = '⚙';
    editButton.addEventListener('click', (event) => editAccount(event, account));
    row.append(button, editButton);
    elements.accountNav.append(row);

    const option = document.createElement('option');
    option.value = account.id;
    option.textContent = `${account.name} <${account.email}>`;
    select.append(option);
  });
}

async function selectAccount(id) {
  state.selectedAccountId = id;
  document.querySelectorAll('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.account === id));
  const account = state.accounts.find((item) => item.id === id);
  elements.viewTitle.textContent = account ? account.name : 'Bandeja unificada';
  clearReader();
  await loadMessages();
}

async function loadMessages() {
  if (!state.accounts.length) return;
  elements.messageList.innerHTML = '<div class="loading">Conectando con tus buzones…</div>';
  elements.statusText.textContent = state.settings.autoTranslate && state.settings.hasOpenRouterKey ? 'Actualizando y traduciendo…' : 'Actualizando…';
  try {
    const result = await window.maildesk.messages.list({ limit: 50, accountId: state.selectedAccountId || undefined });
    state.messages = result.messages;
    renderMessages();
    elements.statusText.textContent = `${state.messages.length} mensajes recientes${result.errors.length ? ` · ${result.errors.length} cuenta(s) con error` : ''}`;
    const notices = [...result.errors.map((item) => item.message), result.aiError].filter(Boolean);
    if (notices.length) showToast(notices.join(' · '));
  } catch (error) {
    elements.messageList.innerHTML = `<div class="loading">${escapeHtml(error.message)}</div>`;
    elements.statusText.textContent = 'No se ha podido actualizar';
  }
}

function renderMessages() {
  const query = elements.searchInput.value.trim().toLowerCase();
  const messages = state.messages.filter((message) => `${message.from} ${message.fromEmail} ${message.subject} ${message.accountEmail}`.toLowerCase().includes(query));
  elements.messageList.replaceChildren();
  if (!messages.length) {
    elements.messageList.innerHTML = '<div class="empty-state"><div class="empty-icon">✉</div><h2>No hay mensajes</h2><p>Prueba a actualizar o cambia la búsqueda.</p></div>';
    return;
  }

  messages.forEach((message) => {
    const card = document.createElement('button');
    card.className = `message-card${message.unread ? ' unread' : ''}`;
    const top = document.createElement('div');
    top.className = 'message-top';
    const sender = document.createElement('span');
    sender.className = 'sender';
    sender.textContent = message.from || message.fromEmail || 'Remitente desconocido';
    const date = document.createElement('span');
    date.className = 'date';
    date.textContent = formatDate(message.date);
    top.append(sender, date);
    const subject = document.createElement('div');
    subject.className = 'subject';
    subject.textContent = message.subject;
    const chip = document.createElement('div');
    chip.className = 'account-chip';
    const dot = document.createElement('span');
    dot.className = 'account-dot';
    dot.style.background = message.accountColor;
    chip.append(dot, document.createTextNode(message.accountEmail));
    card.append(top, subject, chip);
    card.addEventListener('click', () => openMessage(message, card));
    elements.messageList.append(card);
  });
}

async function openMessage(message, card) {
  document.querySelectorAll('.message-card').forEach((item) => item.classList.remove('active'));
  card.classList.add('active');
  card.classList.remove('unread');
  elements.reader.innerHTML = '<div class="loading">Abriendo y traduciendo mensaje…</div>';
  state.selectedMessage = message;
  try {
    const detail = await window.maildesk.messages.read({ accountId: message.accountId, uid: message.uid });
    state.selectedDetail = detail;
    renderReader(message, detail);
  } catch (error) {
    elements.reader.innerHTML = `<div class="loading">${escapeHtml(error.message)}</div>`;
  }
}

function renderReader(message, detail) {
  const wrapper = document.createElement('article');
  wrapper.className = 'reader-content';

  const title = document.createElement('h2');
  title.textContent = detail.subject;
  wrapper.append(title);

  if (detail.translated) {
    const badge = document.createElement('div');
    badge.className = 'translation-badge';
    badge.textContent = `✦ Traducido automáticamente del idioma ${languageName(detail.originalLanguage)}`;
    wrapper.append(badge);
  }
  if (detail.translationError) {
    const warning = document.createElement('div');
    warning.className = 'translation-warning';
    warning.textContent = `No se ha podido traducir: ${detail.translationError}`;
    wrapper.append(warning);
  }

  const meta = document.createElement('div');
  meta.className = 'message-meta';
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = (message.from || '?').slice(0, 1).toUpperCase();
  const lines = document.createElement('div');
  lines.className = 'meta-line';
  lines.innerHTML = `<strong>${escapeHtml(detail.from)}</strong><br>Para: ${escapeHtml(detail.to)}${detail.cc ? `<br>CC: ${escapeHtml(detail.cc)}` : ''}<br>${escapeHtml(formatFullDate(detail.date))}`;
  meta.append(avatar, lines);

  const body = document.createElement('div');
  body.className = 'email-body';
  body.innerHTML = detail.html;
  body.querySelectorAll('a').forEach((link) => {
    link.removeAttribute('target');
    link.removeAttribute('href');
  });
  if (!state.settings.loadRemoteImages) {
    body.querySelectorAll('img').forEach((image) => {
      if (/^https?:/i.test(image.src)) {
        image.dataset.remoteSrc = image.src;
        image.removeAttribute('src');
        image.alt = image.alt || '[Imagen externa bloqueada]';
      }
    });
  }

  wrapper.append(meta, createToolbar(message, detail), body);
  if (detail.attachments.length) {
    const attachments = document.createElement('div');
    attachments.className = 'attachment-list';
    attachments.textContent = `Adjuntos: ${detail.attachments.map((item) => `${item.filename} (${formatBytes(item.size)})`).join(', ')}`;
    wrapper.append(attachments);
  }
  elements.reader.replaceChildren(wrapper);
}

function createToolbar(message, detail) {
  const toolbar = document.createElement('div');
  toolbar.className = 'reader-toolbar';
  const actions = [
    ['↩', 'Responder', () => openComposeDialog({ mode: 'reply', message, detail })],
    ['↩↩', 'Responder a todos', () => openComposeDialog({ mode: 'replyAll', message, detail })],
    ['→', 'Reenviar', () => openComposeDialog({ mode: 'forward', message, detail })],
    ['│', '', null],
    ['▣', 'Archivar', () => executeMessageAction('archive')],
    ['✉', 'No leído', () => executeMessageAction('unread')],
    ['★', 'Destacar', () => executeMessageAction('star')],
    ['!', 'Spam', () => executeMessageAction('spam')],
    ['⌫', 'Papelera', () => executeMessageAction('trash'), 'danger']
  ];
  actions.forEach(([icon, label, handler, extraClass]) => {
    if (!handler) {
      const separator = document.createElement('span');
      separator.className = 'toolbar-separator';
      toolbar.append(separator);
      return;
    }
    const button = document.createElement('button');
    button.className = `reader-action ${extraClass || ''}`;
    button.type = 'button';
    button.innerHTML = `<span>${icon}</span><span>${label}</span>`;
    button.addEventListener('click', handler);
    toolbar.append(button);
  });
  return toolbar;
}

async function executeMessageAction(action) {
  if (!state.selectedMessage) return;
  const labels = { archive: 'Archivando…', unread: 'Marcando como no leído…', star: 'Destacando…', spam: 'Moviendo a spam…', trash: 'Moviendo a la papelera…' };
  showToast(labels[action] || 'Procesando…');
  try {
    await window.maildesk.messages.action({
      accountId: state.selectedMessage.accountId,
      uid: state.selectedMessage.uid,
      action
    });
    clearReader();
    await loadMessages();
    showToast('Acción completada');
  } catch (error) {
    showToast(error.message);
  }
}

function clearReader() {
  state.selectedMessage = null;
  state.selectedDetail = null;
  elements.reader.innerHTML = '<div class="reader-placeholder"><div>✉</div><h2>Selecciona un mensaje</h2><p>Aquí aparecerá el contenido del correo.</p></div>';
}

function openAccountDialog() {
  elements.accountForm.reset();
  elements.accountForm.elements.imapPort.value = '993';
  elements.accountForm.elements.smtpPort.value = '465';
  elements.accountForm.elements.imapSecure.checked = true;
  elements.accountForm.elements.smtpSecure.checked = true;
  elements.accountForm.elements.color.value = '#6750a4';
  elements.accountError.textContent = '';
  updateSignaturePreview();
  elements.accountDialog.showModal();
}

function editAccount(event, account) {
  event.preventDefault();
  openAccountDialog();
  const form = elements.accountForm.elements;
  form.id.value = account.id;
  form.name.value = account.name;
  form.email.value = account.email;
  form.color.value = account.color;
  form.imapHost.value = account.imap.host;
  form.imapPort.value = account.imap.port;
  form.imapSecure.checked = account.imap.secure;
  form.imapUser.value = account.imap.user;
  form.smtpHost.value = account.smtp.host;
  form.smtpPort.value = account.smtp.port;
  form.smtpSecure.checked = account.smtp.secure;
  form.smtpUser.value = account.smtp.user;
  form.signatureHtml.value = account.signatureHtml || '';
  updateSignaturePreview();
}

function accountFromForm() {
  const form = elements.accountForm.elements;
  return {
    id: form.id.value || undefined,
    name: form.name.value,
    email: form.email.value,
    password: form.password.value,
    color: form.color.value,
    imap: { host: form.imapHost.value, port: form.imapPort.value, secure: form.imapSecure.checked, user: form.imapUser.value },
    smtp: { host: form.smtpHost.value, port: form.smtpPort.value, secure: form.smtpSecure.checked, user: form.smtpUser.value },
    signatureHtml: form.signatureHtml.value
  };
}

function updateSignaturePreview() {
  const preview = document.querySelector('#signaturePreview');
  const html = elements.accountForm.elements.signatureHtml.value.trim();
  preview.innerHTML = html || '<span>Vista previa de la firma</span>';
  preview.querySelectorAll('script, iframe, object, embed, form').forEach((element) => element.remove());
  preview.querySelectorAll('*').forEach((element) => {
    [...element.attributes].forEach((attribute) => {
      if (/^on/i.test(attribute.name) || /javascript:/i.test(attribute.value)) element.removeAttribute(attribute.name);
    });
  });
}

async function testAccount() {
  elements.accountError.textContent = 'Probando conexión segura…';
  try {
    await window.maildesk.accounts.test(accountFromForm());
    elements.accountError.textContent = '';
    showToast('Conexión IMAP y SMTP correcta');
  } catch (error) {
    elements.accountError.textContent = error.message;
  }
}

async function saveAccount(event) {
  event.preventDefault();
  elements.accountError.textContent = '';
  try {
    await window.maildesk.accounts.save(accountFromForm());
    elements.accountDialog.close();
    state.accounts = await window.maildesk.accounts.list();
    renderAccounts();
    showToast('Cuenta guardada');
    await loadMessages();
  } catch (error) {
    elements.accountError.textContent = error.message;
  }
}

function openComposeDialog(context = null) {
  if (!state.accounts.length) return showToast('Primero debes añadir una cuenta');
  elements.composeForm.reset();
  document.querySelector('#messageEditor').innerHTML = '';
  elements.composeError.textContent = '';
  elements.translationNotice.textContent = '';
  state.composeContext = context;
  const form = elements.composeForm.elements;
  const editor = document.querySelector('#messageEditor');

  if (context) {
    const { mode, message, detail } = context;
    form.accountId.value = message.accountId;
    form.targetLanguage.value = detail.originalLanguage || 'und';
    form.inReplyTo.value = detail.messageId || '';
    form.references.value = [...(detail.references || []), detail.messageId].filter(Boolean).join('\n');

    if (mode === 'reply' || mode === 'replyAll') {
      form.to.value = detail.fromAddress;
      form.subject.value = replySubject(detail.subject);
      if (mode === 'replyAll') {
        const ownAddress = message.accountEmail.toLowerCase();
        const recipients = new Set([detail.fromAddress, ...detail.toAddresses, ...detail.ccAddresses].filter(Boolean));
        const filtered = [...recipients].filter((address) => address.toLowerCase() !== ownAddress);
        form.to.value = filtered.shift() || detail.fromAddress;
        form.cc.value = filtered.join(', ');
      }
      if (detail.originalLanguage && detail.originalLanguage !== 'es' && detail.originalLanguage !== 'und') {
        elements.translationNotice.textContent = `Escribe en español. Antes de enviar se traducirá automáticamente al ${languageName(detail.originalLanguage)}.`;
      }
    } else if (mode === 'forward') {
      form.subject.value = forwardSubject(detail.subject);
      editor.innerHTML = `<p><br></p><hr><p><strong>Mensaje reenviado</strong><br>De: ${escapeHtml(detail.from)}<br>Fecha: ${escapeHtml(formatFullDate(detail.date))}<br>Asunto: ${escapeHtml(detail.subject)}<br>Para: ${escapeHtml(detail.to)}</p><blockquote>${detail.html}</blockquote>`;
      form.targetLanguage.value = '';
      form.inReplyTo.value = '';
      form.references.value = '';
    }
  }
  appendComposeSignature(form.accountId.value);
  elements.composeDialog.showModal();
}

async function generateDraft() {
  const form = elements.composeForm.elements;
  const instruction = form.aiInstruction.value.trim();
  elements.composeError.textContent = 'La IA está preparando el borrador…';
  try {
    const draft = await window.maildesk.ai.draft({
      instruction,
      message: state.composeContext?.detail || null
    });
    if (draft.subject && !form.subject.value) form.subject.value = draft.subject;
    const editor = document.querySelector('#messageEditor');
    const signature = editor.querySelector('[data-maildesk-signature]')?.outerHTML || '';
    editor.innerHTML = `${textToEditorHtml(draft.body)}${signature}`;
    elements.composeError.textContent = '';
    showToast('Borrador generado en español');
  } catch (error) {
    elements.composeError.textContent = error.message;
  }
}

async function sendMessage(event) {
  event.preventDefault();
  const form = elements.composeForm.elements;
  const editor = document.querySelector('#messageEditor');
  const plainBody = editor.innerText.trim();
  if (!plainBody) {
    elements.composeError.textContent = 'Escribe el contenido del mensaje.';
    return;
  }
  const targetLanguage = form.targetLanguage.value;
  elements.composeError.textContent = targetLanguage && !['es', 'und'].includes(targetLanguage)
    ? 'Traduciendo al idioma original y enviando…'
    : 'Enviando…';
  try {
    await window.maildesk.messages.send({
      accountId: form.accountId.value,
      to: form.to.value,
      cc: form.cc.value,
      bcc: form.bcc.value,
      subject: form.subject.value,
      body: plainBody,
      html: editor.innerHTML,
      targetLanguage,
      inReplyTo: form.inReplyTo.value,
      references: form.references.value.split('\n').filter(Boolean)
    });
    elements.composeDialog.close();
    showToast('Mensaje enviado correctamente');
  } catch (error) {
    elements.composeError.textContent = error.message;
  }
}

async function openSettingsDialog() {
  state.settings = await window.maildesk.settings.get();
  const form = elements.settingsForm.elements;
  form.openRouterKey.value = '';
  form.openRouterModel.value = state.settings.openRouterModel;
  form.autoTranslate.checked = state.settings.autoTranslate;
  form.translateReplies.checked = state.settings.translateReplies;
  form.loadRemoteImages.checked = state.settings.loadRemoteImages;
  elements.settingsStatus.textContent = state.settings.hasOpenRouterKey ? 'Hay una clave de OpenRouter configurada.' : 'Todavía no hay una clave de OpenRouter configurada.';
  elements.settingsError.textContent = '';
  elements.settingsDialog.showModal();
}

async function saveSettings(event) {
  event.preventDefault();
  const form = elements.settingsForm.elements;
  elements.settingsError.textContent = '';
  try {
    state.settings = await window.maildesk.settings.save({
      openRouterKey: form.openRouterKey.value,
      openRouterModel: form.openRouterModel.value,
      autoTranslate: form.autoTranslate.checked,
      translateReplies: form.translateReplies.checked,
      loadRemoteImages: form.loadRemoteImages.checked
    });
    elements.settingsDialog.close();
    showToast('Ajustes guardados');
    if (state.accounts.length) await loadMessages();
  } catch (error) {
    elements.settingsError.textContent = error.message;
  }
}

async function checkForUpdates() {
  elements.updateStatus.textContent = 'Buscando actualizaciones…';
  try {
    const result = await window.maildesk.updater.check();
    if (!result.ok) elements.updateStatus.textContent = result.message;
  } catch (error) {
    elements.updateStatus.textContent = error.message;
  }
}

function handleUpdaterStatus({ status, message }) {
  elements.updateStatus.textContent = message;
  elements.installUpdateButton.hidden = status !== 'ready';
  if (status === 'ready') showToast(message);
}

function runEditorCommand(command, value = null) {
  const editor = document.querySelector('#messageEditor');
  editor.focus();
  document.execCommand(command, false, value);
}

function insertEditorLink() {
  const url = window.prompt('Dirección del enlace (https://…)');
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) return showToast('El enlace debe comenzar por http:// o https://');
  runEditorCommand('createLink', url);
}

function appendComposeSignature(accountId) {
  const editor = document.querySelector('#messageEditor');
  if (editor.querySelector('[data-maildesk-signature]')) return;
  const account = state.accounts.find((item) => item.id === accountId);
  if (!account?.signatureHtml) return;
  editor.insertAdjacentHTML('beforeend', `<div data-maildesk-signature="true"><br>${account.signatureHtml}</div>`);
}

function replaceComposeSignature(accountId) {
  const editor = document.querySelector('#messageEditor');
  editor.querySelectorAll('[data-maildesk-signature]').forEach((signature) => signature.remove());
  appendComposeSignature(accountId);
}

function textToEditorHtml(text) {
  return String(text || '')
    .split(/\n{2,}/)
    .map((paragraph) => `<p>${escapeHtml(paragraph).replaceAll('\n', '<br>')}</p>`)
    .join('');
}

function replySubject(subject) {
  return /^re:/i.test(subject) ? subject : `Re: ${subject}`;
}

function forwardSubject(subject) {
  return /^(fw|fwd):/i.test(subject) ? subject : `Fwd: ${subject}`;
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add('visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => elements.toast.classList.remove('visible'), 4200);
}

function languageName(code) {
  const names = { en: 'inglés', fr: 'francés', de: 'alemán', it: 'italiano', pt: 'portugués', ca: 'catalán', nl: 'neerlandés', es: 'español', und: 'idioma original' };
  return names[String(code || '').toLowerCase()] || String(code || 'original').toUpperCase();
}

function formatDate(date) {
  const value = new Date(date);
  const today = new Date();
  return value.toDateString() === today.toDateString()
    ? value.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
    : value.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
}

function formatFullDate(date) {
  return date ? new Date(date).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' }) : '';
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`;
}

function stripHtml(html) {
  const container = document.createElement('div');
  container.innerHTML = html;
  return container.textContent || '';
}

function escapeHtml(value) {
  return String(value || '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

init();
