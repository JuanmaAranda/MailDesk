const { ImapFlow } = require('imapflow');
const nodemailer = require('nodemailer');
const { simpleParser } = require('mailparser');

class MailService {
  constructor(accountStore, aiService, settingsStore) {
    this.accountStore = accountStore;
    this.aiService = aiService;
    this.settingsStore = settingsStore;
  }

  imapClient(account) {
    return new ImapFlow({
      host: account.imap.host,
      port: account.imap.port,
      secure: account.imap.secure,
      auth: { user: account.imap.user, pass: account.password },
      logger: false,
      tls: { rejectUnauthorized: true }
    });
  }

  async test(input) {
    const account = input.id && !input.password
      ? { ...input, password: this.accountStore.getWithPassword(input.id).password }
      : input;
    const client = this.imapClient(account);
    try {
      await client.connect();
      await client.mailboxOpen('INBOX', { readOnly: true });
      const transport = nodemailer.createTransport(this.smtpOptions(account));
      await transport.verify();
      return { ok: true };
    } finally {
      if (client.usable) await client.logout().catch(() => {});
    }
  }

  async listUnified({ limit = 30, accountId } = {}) {
    const accounts = accountId
      ? [this.accountStore.getWithPassword(accountId)]
      : this.accountStore.listPublic().map((account) => this.accountStore.getWithPassword(account.id));
    const results = await Promise.allSettled(accounts.map((account) => this.listAccount(account, limit)));
    let messages = [];
    const errors = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') messages.push(...result.value);
      else errors.push({ accountId: accounts[index].id, message: friendlyError(result.reason) });
    });
    messages.sort((a, b) => new Date(b.date) - new Date(a.date));
    messages = messages.slice(0, limit);

    let aiError = '';
    try {
      messages = await this.aiService.translateSubjects(messages);
    } catch (error) {
      aiError = `No se han podido traducir los asuntos: ${error.message}`;
    }
    return { messages, errors, aiError };
  }

  async listAccount(account, limit) {
    const client = this.imapClient(account);
    try {
      await client.connect();
      const mailbox = await client.mailboxOpen('INBOX', { readOnly: true });
      if (!mailbox.exists) return [];
      const start = Math.max(1, mailbox.exists - limit + 1);
      const messages = [];
      for await (const item of client.fetch(`${start}:*`, { uid: true, envelope: true, flags: true })) {
        messages.push({
          accountId: account.id,
          accountName: account.name,
          accountEmail: account.email,
          accountColor: account.color,
          uid: item.uid,
          subject: item.envelope?.subject || '(Sin asunto)',
          from: formatAddress(item.envelope?.from?.[0]),
          fromEmail: item.envelope?.from?.[0]?.address || '',
          to: formatAddress(item.envelope?.to?.[0]),
          date: item.envelope?.date?.toISOString() || new Date().toISOString(),
          unread: !item.flags?.has('\\Seen'),
          flagged: item.flags?.has('\\Flagged') || false
        });
      }
      return messages;
    } finally {
      if (client.usable) await client.logout().catch(() => {});
    }
  }

  async read({ accountId, uid }) {
    const account = this.accountStore.getWithPassword(accountId);
    const client = this.imapClient(account);
    try {
      await client.connect();
      await client.mailboxOpen('INBOX');
      const item = await client.fetchOne(uid, { source: true }, { uid: true });
      if (!item?.source) throw new Error('No se ha podido abrir el mensaje.');
      await client.messageFlagsAdd(uid, ['\\Seen'], { uid: true });
      const parsed = await simpleParser(item.source);
      const message = {
        subject: parsed.subject || '(Sin asunto)',
        from: parsed.from?.text || '',
        fromAddress: parsed.replyTo?.value?.[0]?.address || parsed.from?.value?.[0]?.address || '',
        to: parsed.to?.text || '',
        toAddresses: (parsed.to?.value || []).map((address) => address.address).filter(Boolean),
        cc: parsed.cc?.text || '',
        ccAddresses: (parsed.cc?.value || []).map((address) => address.address).filter(Boolean),
        date: parsed.date?.toISOString() || '',
        messageId: parsed.messageId || '',
        references: Array.isArray(parsed.references) ? parsed.references : parsed.references ? [parsed.references] : [],
        html: sanitizeEmailHtml(embedInlineImages(parsed.html || textToHtml(parsed.text || ''), parsed.attachments)),
        text: parsed.text || '',
        attachments: parsed.attachments.map((attachment) => ({
          filename: attachment.filename || 'archivo',
          contentType: attachment.contentType,
          size: attachment.size
        }))
      };
      try {
        return await this.aiService.translateInbound(`${accountId}:${uid}`, message);
      } catch (error) {
        return { ...message, originalLanguage: 'und', translated: false, translationError: error.message };
      }
    } finally {
      if (client.usable) await client.logout().catch(() => {});
    }
  }

  async action({ accountId, uid, action }) {
    const account = this.accountStore.getWithPassword(accountId);
    const client = this.imapClient(account);
    try {
      await client.connect();
      await client.mailboxOpen('INBOX');
      if (action === 'unread') {
        await client.messageFlagsRemove(uid, ['\\Seen'], { uid: true });
        return { ok: true };
      }
      if (action === 'star') {
        await client.messageFlagsAdd(uid, ['\\Flagged'], { uid: true });
        return { ok: true };
      }
      const folders = await client.list();
      const destination = findDestination(folders, action);
      if (!destination) throw new Error(`No se encuentra la carpeta necesaria para ${actionLabel(action)}.`);
      await client.messageMove(uid, destination, { uid: true });
      return { ok: true };
    } finally {
      if (client.usable) await client.logout().catch(() => {});
    }
  }

  async send(input) {
    const message = await this.aiService.translateOutbound(input);
    const account = this.accountStore.getWithPassword(message.accountId);
    const transport = nodemailer.createTransport(this.smtpOptions(account));
    const result = await transport.sendMail({
      from: `"${account.name.replaceAll('"', '')}" <${account.email}>`,
      to: message.to,
      cc: message.cc || undefined,
      bcc: message.bcc || undefined,
      subject: message.subject || '',
      text: message.body || '',
      html: message.html || undefined,
      inReplyTo: message.inReplyTo || undefined,
      references: message.references?.length ? message.references : undefined
    });
    return { ok: true, messageId: result.messageId, translated: message !== input };
  }

  smtpOptions(account) {
    return {
      host: account.smtp.host,
      port: account.smtp.port,
      secure: account.smtp.secure,
      auth: { user: account.smtp.user, pass: account.password },
      tls: { rejectUnauthorized: true }
    };
  }
}

function findDestination(folders, action) {
  const rules = {
    archive: { special: '\\Archive', names: ['Archive', 'Archives', 'Archivado', 'Archivo'] },
    trash: { special: '\\Trash', names: ['Trash', 'Deleted Messages', 'Deleted Items', 'Papelera'] },
    spam: { special: '\\Junk', names: ['Junk', 'Spam', 'Correo no deseado'] }
  };
  const rule = rules[action];
  if (!rule) return '';
  const special = folders.find((folder) => folder.specialUse === rule.special);
  if (special) return special.path;
  const named = folders.find((folder) => rule.names.some((name) => folder.path.toLowerCase() === name.toLowerCase()));
  return named?.path || '';
}

function actionLabel(action) {
  return ({ archive: 'archivar', trash: 'borrar', spam: 'marcar como spam' })[action] || action;
}

function formatAddress(address) {
  if (!address) return '';
  return address.name || address.address || '';
}

function friendlyError(error) {
  if (error?.authenticationFailed) return 'Usuario o contraseña incorrectos.';
  if (error?.code === 'ECONNREFUSED') return 'El servidor ha rechazado la conexión.';
  if (error?.code === 'ETIMEDOUT') return 'El servidor ha tardado demasiado en responder.';
  return error?.message || 'No se ha podido conectar con el buzón.';
}

function textToHtml(text) {
  return `<pre>${escapeHtml(text)}</pre>`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function sanitizeEmailHtml(html) {
  return String(html)
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
    .replace(/<(iframe|object|embed|form|base|meta|link)[\s\S]*?>[\s\S]*?<\/\1>/gi, '')
    .replace(/<(iframe|object|embed|form|base|meta|link)[^>]*\/?>/gi, '')
    .replace(/\son\w+\s*=\s*(["']).*?\1/gi, '')
    .replace(/javascript:/gi, '');
}

function embedInlineImages(html, attachments) {
  let result = String(html);
  for (const attachment of attachments || []) {
    if (!attachment.cid || !attachment.content || !attachment.contentType?.startsWith('image/')) continue;
    const dataUrl = `data:${attachment.contentType};base64,${attachment.content.toString('base64')}`;
    const escapedCid = attachment.cid.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    result = result.replace(new RegExp(`cid:${escapedCid}`, 'gi'), dataUrl);
  }
  return result;
}

module.exports = { MailService };
