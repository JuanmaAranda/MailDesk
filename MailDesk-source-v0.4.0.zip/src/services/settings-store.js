const fs = require('node:fs');
const path = require('node:path');
const { safeStorage } = require('electron');

const DEFAULTS = {
  openRouterModel: 'openai/gpt-4.1-mini',
  autoTranslate: true,
  translateReplies: true,
  loadRemoteImages: true
};

class SettingsStore {
  constructor(userDataPath) {
    this.filePath = path.join(userDataPath, 'settings.json');
  }

  read() {
    if (!fs.existsSync(this.filePath)) return { ...DEFAULTS };
    try {
      return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(this.filePath, 'utf8')) };
    } catch {
      return { ...DEFAULTS };
    }
  }

  getPublic() {
    const { encryptedOpenRouterKey, ...settings } = this.read();
    return { ...settings, hasOpenRouterKey: Boolean(encryptedOpenRouterKey) };
  }

  getSecret() {
    const settings = this.read();
    return {
      ...settings,
      openRouterKey: settings.encryptedOpenRouterKey
        ? safeStorage.decryptString(Buffer.from(settings.encryptedOpenRouterKey, 'base64'))
        : ''
    };
  }

  save(input) {
    const previous = this.read();
    let encryptedOpenRouterKey = previous.encryptedOpenRouterKey;
    if (input.openRouterKey?.trim()) {
      if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows no permite cifrar la clave en este momento.');
      encryptedOpenRouterKey = safeStorage.encryptString(input.openRouterKey.trim()).toString('base64');
    }
    if (input.clearOpenRouterKey) encryptedOpenRouterKey = undefined;

    const settings = {
      openRouterModel: input.openRouterModel?.trim() || DEFAULTS.openRouterModel,
      autoTranslate: Boolean(input.autoTranslate),
      translateReplies: Boolean(input.translateReplies),
      loadRemoteImages: Boolean(input.loadRemoteImages),
      encryptedOpenRouterKey
    };
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const temporaryPath = `${this.filePath}.tmp`;
    fs.writeFileSync(temporaryPath, JSON.stringify(settings, null, 2), { mode: 0o600 });
    fs.renameSync(temporaryPath, this.filePath);
    return this.getPublic();
  }
}

module.exports = { SettingsStore };
