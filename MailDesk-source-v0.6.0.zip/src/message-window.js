const root = document.querySelector('#messageWindow');
const toast = document.querySelector('#toast');

window.maildesk.messages.onWindowData(({ message, detail, theme, loadRemoteImages }) => {
  document.documentElement.dataset.theme = theme || 'light';
  document.title = `${detail.subject || 'Mensaje'} · MailDesk`;
  const article = document.createElement('article');
  article.className = 'reader-content popup-reader-content';
  const title = document.createElement('h2');
  title.textContent = detail.subject;
  const meta = document.createElement('div');
  meta.className = 'message-meta';
  meta.innerHTML = `<div class="avatar">${escapeHtml((message.from || '?').slice(0, 1).toUpperCase())}</div><div class="meta-line"><strong>${escapeHtml(detail.from)}</strong><br>Para: ${escapeHtml(detail.to)}${detail.cc ? `<br>CC: ${escapeHtml(detail.cc)}` : ''}<br>${escapeHtml(formatFullDate(detail.date))}</div>`;
  const frame = document.createElement('iframe');
  frame.className = 'email-frame popup-email-frame';
  frame.title = 'Contenido del mensaje';
  frame.setAttribute('sandbox', 'allow-same-origin allow-popups allow-popups-to-escape-sandbox');
  frame.setAttribute('referrerpolicy', 'no-referrer');
  frame.srcdoc = prepareEmailDocument(detail.html, loadRemoteImages);
  article.append(title, meta, frame);
  if (detail.attachments?.length) article.append(createAttachments(message, detail.attachments));
  root.replaceChildren(article);
});

function createAttachments(message, items) {
  const section = document.createElement('section');
  section.className = 'attachment-list';
  section.innerHTML = `<strong>📎 ${items.length} archivo${items.length === 1 ? '' : 's'} adjunto${items.length === 1 ? '' : 's'}</strong>`;
  const grid = document.createElement('div');
  grid.className = 'attachment-grid';
  items.forEach((item) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'attachment-card';
    button.innerHTML = `<span class="attachment-icon">📄</span><span><strong>${escapeHtml(item.filename)}</strong><small>${formatBytes(item.size)}</small></span><span class="attachment-download">↓</span>`;
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        const result = await window.maildesk.messages.saveAttachment({ accountId: message.accountId, uid: message.uid, attachmentId: item.id });
        if (result.ok) showToast('Archivo adjunto guardado');
      } catch (error) {
        showToast(error.message);
      } finally {
        button.disabled = false;
      }
    });
    grid.append(button);
  });
  section.append(grid);
  return section;
}

function prepareEmailDocument(html, loadRemoteImages) {
  const parser = new DOMParser();
  const documentValue = parser.parseFromString(String(html || ''), 'text/html');
  documentValue.querySelectorAll('script, iframe, object, embed, form, base, meta[http-equiv="refresh"]').forEach((element) => element.remove());
  documentValue.querySelectorAll('*').forEach((element) => [...element.attributes].forEach((attribute) => {
    if (/^on/i.test(attribute.name) || /javascript:/i.test(attribute.value)) element.removeAttribute(attribute.name);
  }));
  documentValue.querySelectorAll('a[href]').forEach((link) => {
    if (!/^https?:/i.test(link.href)) link.removeAttribute('href');
    else { link.target = '_blank'; link.rel = 'noopener noreferrer'; }
  });
  if (!loadRemoteImages) documentValue.querySelectorAll('img').forEach((image) => { if (/^https?:/i.test(image.src)) image.removeAttribute('src'); });
  const security = documentValue.createElement('meta');
  security.httpEquiv = 'Content-Security-Policy';
  security.content = "default-src 'none'; img-src data: https:; style-src 'unsafe-inline' https:; font-src data: https:; frame-src 'none'; object-src 'none'; form-action 'none'";
  const style = documentValue.createElement('style');
  style.textContent = 'html,body{margin:0;padding:0;background:#fff;color:#222;max-width:100%;overflow-x:auto}body{padding:2px;font-family:Arial,sans-serif}img{max-width:100%;height:auto}table{max-width:100%}pre{white-space:pre-wrap}';
  documentValue.head.prepend(security, style);
  return `<!doctype html>${documentValue.documentElement.outerHTML}`;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('visible');
  setTimeout(() => toast.classList.remove('visible'), 3500);
}

function formatFullDate(date) { return date ? new Date(date).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' }) : ''; }
function formatBytes(bytes) { const units = ['B', 'KB', 'MB', 'GB']; const index = bytes ? Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), 3) : 0; return `${((bytes || 0) / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`; }
function escapeHtml(value) { return String(value || '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;'); }
