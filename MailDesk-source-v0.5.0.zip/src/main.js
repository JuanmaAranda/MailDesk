const path = require('node:path');
const fs = require('node:fs/promises');
const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const { autoUpdater } = require('electron-updater');
const { AccountStore } = require('./services/account-store');
const { SettingsStore } = require('./services/settings-store');
const { AiService } = require('./services/ai-service');
const { MailService } = require('./services/mail-service');

let accountStore;
let settingsStore;
let aiService;
let mailService;
let mainWindow;

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#f6f7f9',
    title: 'MailDesk',
    icon: path.join(__dirname, 'assets', 'maildesk-icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  window.setMenuBarVisibility(false);
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  window.loadFile(path.join(__dirname, 'index.html'));
  mainWindow = window;
}

function sendUpdaterStatus(status, message = '') {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('updater:status', { status, message });
}

function setupAutoUpdater() {
  if (!app.isPackaged) return;
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => sendUpdaterStatus('checking', 'Buscando actualizaciones…'));
  autoUpdater.on('update-available', (info) => sendUpdaterStatus('downloading', `Descargando MailDesk ${info.version}…`));
  autoUpdater.on('update-not-available', () => sendUpdaterStatus('current', 'MailDesk está actualizado.'));
  autoUpdater.on('download-progress', (progress) => sendUpdaterStatus('downloading', `Descargando actualización: ${Math.round(progress.percent)} %`));
  autoUpdater.on('update-downloaded', (info) => sendUpdaterStatus('ready', `MailDesk ${info.version} está listo para instalar.`));
  autoUpdater.on('error', (error) => sendUpdaterStatus('error', `No se ha podido actualizar: ${error.message}`));
  setTimeout(() => autoUpdater.checkForUpdates().catch(() => {}), 8000);
}

function registerHandlers() {
  ipcMain.handle('accounts:list', () => accountStore.listPublic());
  ipcMain.handle('accounts:save', (_event, account) => accountStore.save(account));
  ipcMain.handle('accounts:remove', (_event, id) => accountStore.remove(id));
  ipcMain.handle('accounts:test', (_event, account) => mailService.test(account));
  ipcMain.handle('settings:get', () => settingsStore.getPublic());
  ipcMain.handle('settings:save', (_event, settings) => settingsStore.save(settings));
  ipcMain.handle('messages:list', (_event, options) => mailService.listUnified(options));
  ipcMain.handle('messages:read', (_event, request) => mailService.read(request));
  ipcMain.handle('messages:translate', (_event, request) => mailService.translate(request));
  ipcMain.handle('messages:action', (_event, request) => mailService.action(request));
  ipcMain.handle('messages:send', (_event, message) => mailService.send(message));
  ipcMain.handle('messages:save-attachment', async (_event, request) => {
    const attachment = await mailService.attachment(request);
    const safeName = path.basename(attachment.filename).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(mainWindow, { defaultPath: safeName });
    if (result.canceled || !result.filePath) return { ok: false, canceled: true };
    await fs.writeFile(result.filePath, attachment.content);
    return { ok: true, filePath: result.filePath };
  });
  ipcMain.handle('ai:draft', (_event, request) => aiService.draftReply(request));
  ipcMain.handle('updater:check', async () => {
    if (!app.isPackaged) return { ok: false, message: 'Las actualizaciones solo funcionan en la versión instalada.' };
    await autoUpdater.checkForUpdates();
    return { ok: true };
  });
  ipcMain.handle('updater:install', () => {
    autoUpdater.quitAndInstall(false, true);
    return { ok: true };
  });
}

app.whenReady().then(() => {
  accountStore = new AccountStore(app.getPath('userData'));
  settingsStore = new SettingsStore(app.getPath('userData'));
  aiService = new AiService(settingsStore);
  mailService = new MailService(accountStore, aiService, settingsStore);
  registerHandlers();
  createWindow();
  setupAutoUpdater();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
