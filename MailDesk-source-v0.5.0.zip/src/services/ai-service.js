class AiService {
  constructor(settingsStore) {
    this.settingsStore = settingsStore;
    this.messageCache = new Map();
    this.subjectCache = new Map();
  }

  isConfigured() {
    return Boolean(this.settingsStore.getSecret().openRouterKey);
  }

  async callJson(system, user) {
    const settings = this.settingsStore.getSecret();
    if (!settings.openRouterKey) throw new Error('Configura primero tu clave de OpenRouter en Ajustes.');

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${settings.openRouterKey}`,
        'Content-Type': 'application/json',
        'X-Title': 'MailDesk'
      },
      body: JSON.stringify({
        model: settings.openRouterModel,
        temperature: 0.2,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user }
        ]
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error?.error?.message || `OpenRouter ha respondido con el error ${response.status}.`);
    }
    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) throw new Error('OpenRouter no ha devuelto contenido.');
    try {
      return JSON.parse(content.replace(/^```json\s*|\s*```$/g, ''));
    } catch {
      throw new Error('La respuesta de la IA no tiene el formato esperado.');
    }
  }

  async translateSubjects(messages) {
    const settings = this.settingsStore.getSecret();
    if (!settings.autoTranslate || !settings.openRouterKey || !messages.length) return messages;
    const candidates = messages
      .map((message, index) => ({ id: index, subject: message.subject }))
      .filter((item) => !this.subjectCache.has(item.subject));
    if (!candidates.length) {
      return messages.map((message) => ({ ...message, originalSubject: message.subject, subject: this.subjectCache.get(message.subject) || message.subject }));
    }
    const result = await this.callJson(
      'Eres un traductor profesional de correo. Devuelve JSON estricto con la propiedad subjects, un array de objetos {id, text}. Traduce cada asunto al español de España. Si ya está en español, consérvalo. No añadas explicaciones ni cambies nombres propios.',
      JSON.stringify(candidates)
    );
    const translations = new Map((result.subjects || []).map((item) => [Number(item.id), item.text]));
    candidates.forEach((item) => this.subjectCache.set(item.subject, translations.get(item.id) || item.subject));
    return messages.map((message, index) => ({
      ...message,
      originalSubject: message.subject,
      subject: this.subjectCache.get(message.subject) || translations.get(index) || message.subject
    }));
  }

  async translateInbound(cacheKey, message) {
    const settings = this.settingsStore.getSecret();
    if (!settings.openRouterKey) throw new Error('Configura primero tu clave de OpenRouter en Ajustes.');
    if (this.messageCache.has(cacheKey)) return this.messageCache.get(cacheKey);

    const result = await this.callJson(
      'Eres un traductor profesional de correo. Detecta el idioma original y traduce asunto y cuerpo al español de España. Conserva exactamente la estructura HTML, etiquetas, enlaces, imágenes, atributos src y estilos; traduce únicamente texto visible y atributos title/alt. No resumas ni añadas información. Devuelve JSON estricto: {originalLanguage, subjectEs, htmlEs}. originalLanguage debe ser un código ISO 639-1 como en, fr, de o es.',
      JSON.stringify({ subject: message.subject, html: message.html.slice(0, 60000) })
    );
    const translated = {
      ...message,
      originalSubject: message.subject,
      originalHtml: message.html,
      subject: result.subjectEs || message.subject,
      html: result.htmlEs || message.html,
      originalLanguage: result.originalLanguage || 'und',
      translated: (result.originalLanguage || 'und') !== 'es',
      translationChecked: true
    };
    this.messageCache.set(cacheKey, translated);
    return translated;
  }

  async draftReply({ instruction, message }) {
    if (!instruction?.trim()) throw new Error('Escribe primero qué quieres responder.');
    const result = await this.callJson(
      'Eres un asistente de correo profesional. Redacta en español de España una respuesta completa siguiendo las instrucciones del usuario y utilizando el correo recibido como contexto. No inventes datos, compromisos, fechas ni cifras. Devuelve JSON estricto: {subject, body}. El cuerpo debe ser texto plano, natural y listo para revisar.',
      JSON.stringify({
        instruction,
        receivedSubject: message?.subject || '',
        receivedFrom: message?.from || '',
        receivedBody: stripHtml(message?.html || '').slice(0, 30000)
      })
    );
    return { subject: result.subject || '', body: result.body || '' };
  }

  async translateOutbound(message) {
    const settings = this.settingsStore.getSecret();
    const language = message.targetLanguage;
    if (!settings.translateReplies || !settings.openRouterKey || !language || ['es', 'spa', 'und'].includes(language)) return message;
    const result = await this.callJson(
      `Traduce un correo desde español de España al idioma cuyo código ISO es ${language}. Mantén exactamente el significado, tono, nombres propios, cifras y formato HTML. No traduzcas el contenido del bloque que tenga el atributo data-maildesk-signature. Devuelve JSON estricto: {subject, body, html}. No añadas explicaciones.`,
      JSON.stringify({ subject: message.subject, body: message.body, html: message.html || '' })
    );
    return {
      ...message,
      subject: result.subject || message.subject,
      body: result.body || message.body,
      html: result.html || message.html
    };
  }
}

function stripHtml(html) {
  return String(html)
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

module.exports = { AiService };
