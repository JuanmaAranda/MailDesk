const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('maildesk', {
  accounts: {
    list: () => ipcRenderer.invoke('accounts:list'),
    save: (account) => ipcRenderer.invoke('accounts:save', account),
    remove: (id) => ipcRenderer.invoke('accounts:remove', id),
    test: (account) => ipcRenderer.invoke('accounts:test', account)
  },
  settings: {
    get: () => ipcRenderer.invoke('settings:get'),
    save: (settings) => ipcRenderer.invoke('settings:save', settings)
  },
  messages: {
    list: (options = {}) => ipcRenderer.invoke('messages:list', options),
    read: (request) => ipcRenderer.invoke('messages:read', request),
    translate: (request) => ipcRenderer.invoke('messages:translate', request),
    action: (request) => ipcRenderer.invoke('messages:action', request),
    send: (message) => ipcRenderer.invoke('messages:send', message),
    saveAttachment: (request) => ipcRenderer.invoke('messages:save-attachment', request)
  },
  ai: {
    draft: (request) => ipcRenderer.invoke('ai:draft', request)
  },
  updater: {
    check: () => ipcRenderer.invoke('updater:check'),
    install: () => ipcRenderer.invoke('updater:install'),
    onStatus: (callback) => ipcRenderer.on('updater:status', (_event, payload) => callback(payload))
  }
});
